'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { FaShoppingCart, FaSearch, FaBars, FaTimes } from 'react-icons/fa';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

export default function Navbar() {
  const { user, signOut } = useAuth();
  const { cartCount } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <nav className="sticky top-0 z-40 bg-forest text-cream shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand text */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-3 group">
              <Image 
                src="/logo.jpg" 
                alt="GK Traders" 
                width={40} 
                height={40} 
                className="mix-blend-screen rounded-full object-cover" 
                priority
              />
              <span className="font-heading font-bold text-xl sm:text-2xl tracking-wide text-cream group-hover:text-leaf transition-colors">
                GK Traders
              </span>
            </Link>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              href="/" 
              className="font-medium text-sm hover:text-leaf transition-colors"
            >
              Home
            </Link>
            <Link 
              href="/products" 
              className="font-medium text-sm hover:text-leaf transition-colors"
            >
              Products
            </Link>
            <Link 
              href="/blog" 
              className="font-medium text-sm text-leaf hover:text-lightaccent transition-colors flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-leaf animate-pulse"></span>
              Blog & Stories
            </Link>
            <Link 
              href="/about" 
              className="font-medium text-sm hover:text-leaf transition-colors"
            >
              About
            </Link>
            <Link 
              href="/contact" 
              className="font-medium text-sm hover:text-leaf transition-colors"
            >
              Contact
            </Link>
          </div>

          {/* Right Side: Search button, Cart icon & User Auth */}
          <div className="hidden md:flex items-center space-x-5">
            {/* Search Icon Button */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-cream hover:text-leaf transition-colors rounded-full hover:bg-darkforest/40 focus:outline-none"
              aria-label="Search products"
            >
              <FaSearch size={18} />
            </button>

            {/* Cart Icon Link */}
            <Link
              href="/cart"
              className="relative p-2 text-cream hover:text-leaf transition-colors rounded-full hover:bg-darkforest/40 flex items-center"
              aria-label="Shopping Cart"
            >
              <FaShoppingCart size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-leaf text-darkforest font-bold text-xs w-5 h-5 rounded-full flex items-center justify-center shadow-sm">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* User Auth Section */}
            {user ? (
              <div className="flex items-center space-x-3">
                <Link
                  href="/orders"
                  className="text-sm font-medium hover:text-leaf transition-colors px-3 py-1.5 rounded-full hover:bg-darkforest/40"
                >
                  Orders
                </Link>
                <button
                  onClick={() => signOut()}
                  className="text-sm font-medium bg-leaf/20 hover:bg-leaf text-cream hover:text-darkforest transition-all px-3 py-1.5 rounded-full border border-leaf/40"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link
                href="/auth/login"
                className="text-sm font-semibold bg-leaf hover:bg-lightaccent text-darkforest transition-colors px-4 py-2 rounded-full shadow-sm"
              >
                Login
              </Link>
            )}
          </div>

          {/* Mobile Right Controls: Search, Cart & Hamburger Button */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-cream hover:text-leaf transition-colors focus:outline-none"
              aria-label="Search products"
            >
              <FaSearch size={18} />
            </button>
            <Link
              href="/cart"
              className="relative p-2 text-cream hover:text-leaf transition-colors flex items-center"
              aria-label="Shopping Cart"
            >
              <FaShoppingCart size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-leaf text-darkforest font-bold text-xs w-5 h-5 rounded-full flex items-center justify-center shadow-sm">
                  {cartCount}
                </span>
              )}
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-cream hover:text-leaf focus:outline-none ml-1"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <FaTimes size={22} /> : <FaBars size={22} />}
            </button>
          </div>

        </div>
      </div>

      {/* Dropdown Search Bar */}
      {searchOpen && (
        <div className="bg-darkforest border-t border-forest/80 px-4 py-3 shadow-inner">
          <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto flex items-center gap-2">
            <div className="relative flex-grow">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search eco products (e.g. bamboo bottle, scrub, toothbrush)..."
                className="w-full bg-forest text-cream placeholder-lightaccent/60 text-sm px-4 py-2 pl-10 rounded-full border border-leaf/40 focus:outline-none focus:border-leaf"
                autoFocus
              />
              <FaSearch className="absolute left-3.5 top-3 text-lightaccent/70" size={14} />
            </div>
            <button
              type="submit"
              className="bg-leaf hover:bg-lightaccent text-darkforest font-semibold text-sm px-4 py-2 rounded-full transition-colors"
            >
              Search
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              className="p-2 text-cream hover:text-leaf focus:outline-none"
              aria-label="Close search"
            >
              <FaTimes size={16} />
            </button>
          </form>
        </div>
      )}

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-darkforest px-4 py-5 space-y-3 border-t border-forest/80 shadow-lg">
          <Link
            href="/"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-cream hover:text-leaf font-medium text-base transition-colors"
          >
            Home
          </Link>
          <Link
            href="/products"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-cream hover:text-leaf font-medium text-base transition-colors"
          >
            Products
          </Link>
          <Link
            href="/blog"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-leaf font-bold text-base transition-colors flex items-center gap-2"
          >
            <span className="w-2 h-2 rounded-full bg-leaf"></span>
            Blog & Stories
          </Link>
          <Link
            href="/about"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-cream hover:text-leaf font-medium text-base transition-colors"
          >
            About
          </Link>
          <Link
            href="/contact"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-cream hover:text-leaf font-medium text-base transition-colors"
          >
            Contact
          </Link>

          <div className="pt-4 border-t border-forest/60 space-y-3">
            <Link
              href="/cart"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-between py-2 text-cream hover:text-leaf font-medium"
            >
              <span className="flex items-center gap-2">
                <FaShoppingCart size={18} />
                Cart
              </span>
              {cartCount > 0 && (
                <span className="bg-leaf text-darkforest font-bold text-xs px-2.5 py-0.5 rounded-full">
                  {cartCount} items
                </span>
              )}
            </Link>

            {user ? (
              <div className="space-y-2 pt-2 border-t border-forest/40">
                <Link
                  href="/orders"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block py-2 text-cream hover:text-leaf font-medium"
                >
                  Orders
                </Link>
                <button
                  onClick={() => {
                    signOut();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left py-2 text-leaf hover:text-lightaccent font-medium"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="pt-2">
                <Link
                  href="/auth/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block w-full text-center bg-leaf text-darkforest font-semibold py-2.5 rounded-full hover:bg-lightaccent transition-colors shadow-sm"
                >
                  Login
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
