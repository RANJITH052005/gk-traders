import Link from 'next/link';
import Image from 'next/image';
import { 
  FaWhatsapp, 
  FaFacebook, 
  FaInstagram, 
  FaEnvelope, 
  FaMapMarkerAlt, 
  FaPhone 
} from 'react-icons/fa';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-darkforest text-lightaccent pt-12 pb-6 border-t border-forest">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Col 1: Logo, GK Traders, Tagline, Social Icons */}
          <div className="col-span-1">
            <Link href="/" className="inline-flex items-center gap-3 mb-4 group">
              <Image 
                src="/logo.jpg" 
                alt="GK Traders Logo" 
                width={40} 
                height={40} 
                className="rounded mix-blend-screen" 
              />
              <span className="font-heading font-bold text-xl text-cream tracking-wide group-hover:text-leaf transition-colors">
                GK Traders
              </span>
            </Link>
            <p className="text-xs sm:text-sm text-lightaccent/80 mb-5 leading-relaxed">
              Sustainable Living Starts Here. 100% plastic-free, natural essentials handcrafted for eco-conscious homes across India.
            </p>
            <div className="flex items-center gap-3">
              <a 
                href="https://wa.me/919841202464" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="w-9 h-9 rounded-full bg-forest flex items-center justify-center text-cream hover:bg-[#25D366] hover:text-white transition-colors shadow-sm"
              >
                <FaWhatsapp size={18} />
              </a>
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="w-9 h-9 rounded-full bg-forest flex items-center justify-center text-cream hover:bg-[#1877F2] hover:text-white transition-colors shadow-sm"
              >
                <FaFacebook size={18} />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-9 h-9 rounded-full bg-forest flex items-center justify-center text-cream hover:bg-[#E4405F] hover:text-white transition-colors shadow-sm"
              >
                <FaInstagram size={18} />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="col-span-1">
            <h3 className="font-heading font-semibold text-cream mb-4 text-sm uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link href="/products" className="hover:text-cream transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-leaf font-semibold hover:text-cream transition-colors">
                  Blog & Eco Stories
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-cream transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-cream transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/admin/messages" className="text-leaf/80 hover:text-cream text-xs transition-colors">
                  Customer Messages (Admin)
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="hover:text-cream transition-colors">
                  Shipping Policy
                </Link>
              </li>
              <li>
                <Link href="/refund-policy" className="hover:text-cream transition-colors">
                  Refund & Cancellation
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-cream transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-cream transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <a 
                  href="https://razorpay.me/@gktraders" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-cream transition-colors text-leaf font-medium inline-flex items-center gap-1"
                >
                  Pay via Razorpay.me ↗
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3-4 (col-span-2): Contact Info */}
          <div className="col-span-1 md:col-span-2">
            <h3 className="font-heading font-semibold text-cream mb-4 text-sm uppercase tracking-wider">
              Contact Info
            </h3>
            <div className="space-y-3.5 text-xs sm:text-sm">
              <div className="flex items-start gap-3">
                <FaMapMarkerAlt className="mt-1 flex-shrink-0 text-leaf text-base" />
                <span className="text-lightaccent/90 leading-relaxed">
                  Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092
                </span>
              </div>
              <div className="flex items-center gap-3">
                <FaPhone className="flex-shrink-0 text-leaf" />
                <a href="tel:+919841202464" className="hover:text-cream transition-colors">
                  9841202464
                </a>
              </div>
              <div className="flex items-center gap-3">
                <FaEnvelope className="flex-shrink-0 text-leaf" />
                <a href="mailto:hellogktraders@gmail.com" className="hover:text-cream transition-colors">
                  hellogktraders@gmail.com
                </a>
              </div>
            </div>

            <div className="mt-6">
              <a 
                href="https://wa.me/919841202464" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[#25D366] text-white px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm hover:bg-[#20bd5a] transition-all shadow-sm"
              >
                <FaWhatsapp size={18} />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-forest/60 pt-6 text-center text-xs opacity-75">
          <p>© {currentYear} GK Traders. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
