'use client';
import { useAuth } from '@/context/AuthContext';
import { FaGoogle } from 'react-icons/fa';

export default function GoogleSignInButton() {
  const { signInWithGoogle } = useAuth();
  
  return (
    <button
      onClick={signInWithGoogle}
      className="w-full flex items-center justify-center gap-3 bg-white border border-gray-300 text-gray-700 px-4 py-2.5 rounded-lg font-medium hover:bg-gray-50 transition-colors shadow-sm"
    >
      <FaGoogle className="text-red-500" />
      Sign in with Google
    </button>
  );
}
