'use client';

import { useState } from 'react';
import { FaPaperPlane, FaWhatsapp, FaCheckCircle, FaSpinner, FaLeaf } from 'react-icons/fa';
import { createClient } from '@/lib/supabase/client';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    inquiryType: 'General Inquiry',
    message: '',
  });

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [waLink, setWaLink] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const submissionTime = new Date().toISOString();
    const newEntry = {
      id: Date.now().toString(),
      name: formData.name.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim(),
      inquiry_type: formData.inquiryType,
      message: formData.message.trim(),
      created_at: submissionTime,
    };

    // 1. Save to Local Storage (always reliable backup)
    try {
      const existing = JSON.parse(localStorage.getItem('gk_contact_messages') || '[]');
      existing.unshift(newEntry);
      localStorage.setItem('gk_contact_messages', JSON.stringify(existing));
    } catch (err) {
      console.warn('Could not save to localStorage:', err);
    }

    // 2. Attempt Save to Supabase
    try {
      const supabase = createClient();
      await supabase.from('contact_messages').insert([
        {
          name: newEntry.name,
          email: newEntry.email,
          phone: newEntry.phone || null,
          inquiry_type: newEntry.inquiry_type,
          message: newEntry.message,
          created_at: submissionTime,
        },
      ]);
    } catch (err) {
      console.warn('Supabase insert note:', err);
    }

    // 3. Format WhatsApp Message for +91 9841202464
    const phoneInfo = formData.phone ? `\n• Phone: ${formData.phone}` : '';
    const msg = encodeURIComponent(
      `Hello GK Traders! 🌿 New Website Message:\n` +
      `• Name: ${formData.name}\n` +
      `• Email: ${formData.email}${phoneInfo}\n` +
      `• Topic: ${formData.inquiryType}\n\n` +
      `Message:\n${formData.message}`
    );

    const fullWaUrl = `https://wa.me/919841202464?text=${msg}`;
    setWaLink(fullWaUrl);

    // Try to open WhatsApp in new tab
    try {
      window.open(fullWaUrl, '_blank');
    } catch (err) {
      console.warn('Popup blocked, link available on screen:', err);
    }

    setLoading(false);
    setSubmitted(true);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      inquiryType: 'General Inquiry',
      message: '',
    });
    setSubmitted(false);
    setWaLink('');
  };

  if (submitted) {
    return (
      <div className="bg-cream/40 rounded-3xl p-8 border border-sand/40 text-center space-y-5 animate-fade-in">
        <div className="w-16 h-16 rounded-full bg-leaf/20 text-forest mx-auto flex items-center justify-center text-3xl">
          <FaCheckCircle className="text-leaf" />
        </div>

        <h3 className="text-2xl font-heading font-bold text-darkforest">
          Thank you, {formData.name}!
        </h3>

        <p className="text-gray-600 text-sm sm:text-base max-w-md mx-auto leading-relaxed">
          Your feedback has been <strong className="text-forest">saved to our database</strong> and forwarded to our team.
        </p>

        {/* WhatsApp Direct Chat Button */}
        {waLink && (
          <div className="pt-2">
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 bg-[#25D366] hover:bg-[#20bd5a] text-white py-3.5 px-6 rounded-2xl font-bold transition-all shadow-md hover:scale-[1.02] transform text-sm cursor-pointer"
            >
              <FaWhatsapp size={19} />
              <span>Continue Chat on WhatsApp (+91 9841202464)</span>
            </a>
          </div>
        )}

        <div className="pt-4 border-t border-sand/30">
          <button
            type="button"
            onClick={handleReset}
            className="text-xs font-semibold text-forest hover:text-darkforest hover:underline cursor-pointer"
          >
            ← Send Another Message
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-heading font-bold text-darkforest mb-2">
        Send Us a Message
      </h2>
      <p className="text-sm text-gray-600 mb-6 leading-relaxed">
        Fill out your details below. Your message will be securely saved and forwarded straight to our team on WhatsApp for immediate support.
      </p>

      {/* Inquiry Topic Pills */}
      <div className="mb-5">
        <label className="block text-xs font-bold text-darkforest mb-2 uppercase tracking-wider">
          Topic / Interest
        </label>
        <div className="flex flex-wrap gap-2">
          {['General Inquiry', 'Bulk / Wholesale Orders', 'Product Question', 'Feedback'].map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setFormData((prev) => ({ ...prev, inquiryType: type }))}
              className={`text-xs px-3.5 py-1.5 rounded-full font-medium transition-all cursor-pointer ${
                formData.inquiryType === type
                  ? 'bg-forest text-cream shadow-xs'
                  : 'bg-white text-gray-700 border border-sand/50 hover:bg-cream'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 mb-6">
        {/* Name */}
        <div>
          <label htmlFor="name" className="block text-xs font-bold text-darkforest mb-1 uppercase tracking-wider">
            Full Name <span className="text-leaf">*</span>
          </label>
          <input
            type="text"
            id="name"
            name="name"
            required
            value={formData.name}
            onChange={handleChange}
            placeholder="Your Full Name"
            className="w-full border border-sand/60 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-forest bg-cream/30 text-darkforest placeholder:text-gray-400"
          />
        </div>

        {/* Email & Phone */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="email" className="block text-xs font-bold text-darkforest mb-1 uppercase tracking-wider">
              Email Address <span className="text-leaf">*</span>
            </label>
            <input
              type="email"
              id="email"
              name="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              className="w-full border border-sand/60 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-forest bg-cream/30 text-darkforest placeholder:text-gray-400"
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-xs font-bold text-darkforest mb-1 uppercase tracking-wider">
              Phone / WhatsApp (Optional)
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="+91 98412 02464"
              className="w-full border border-sand/60 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-forest bg-cream/30 text-darkforest placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Message */}
        <div>
          <label htmlFor="message" className="block text-xs font-bold text-darkforest mb-1 uppercase tracking-wider">
            Your Message / Feedback <span className="text-leaf">*</span>
          </label>
          <textarea
            id="message"
            name="message"
            rows="4"
            required
            value={formData.message}
            onChange={handleChange}
            placeholder="Tell us what products you're looking for, quantity, or share your valuable feedback..."
            className="w-full border border-sand/60 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-forest bg-cream/30 text-darkforest placeholder:text-gray-400"
          ></textarea>
        </div>

        {/* Dual Action Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] font-bold py-3.5 px-8 rounded-xl transition-all shadow-md hover:shadow-lg text-sm cursor-pointer hover:scale-[1.01] transform disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <FaSpinner className="animate-spin" />
              <span>Saving & Connecting...</span>
            </>
          ) : (
            <>
              <FaPaperPlane size={14} />
              <span>Send Message & Open WhatsApp</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
