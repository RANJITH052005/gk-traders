'use client';
import { useState, useEffect } from 'react';
import Image from 'next/image';
import { FaQuoteLeft, FaQuoteRight } from 'react-icons/fa';

const quotes = [
  { 
    text: "The Earth does not belong to us. We belong to the Earth.", 
    author: "Mahatma Gandhi",
    role: "Father of the Nation, India"
  },
  { 
    text: "We do not inherit the Earth from our ancestors, we borrow it from our children.", 
    author: "Dr. A.P.J. Abdul Kalam",
    role: "Former President of India"
  },
  { 
    text: "The environment is where we all meet; where we all have a mutual interest.", 
    author: "Lady Bird Johnson",
    role: "Former First Lady, USA"
  },
  { 
    text: "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves.", 
    author: "Wangari Maathai",
    role: "Nobel Peace Prize Winner"
  },
  { 
    text: "The greatest threat to our planet is the belief that someone else will save it.", 
    author: "Robert Swan",
    role: "Environmental Leader"
  },
  { 
    text: "In every walk with nature, one receives far more than he seeks.", 
    author: "John Muir",
    role: "Father of National Parks"
  },
  { 
    text: "Be the change you wish to see in the world — start with what you use every day.", 
    author: "Narendra Modi",
    role: "Prime Minister of India"
  },
  { 
    text: "Nature provides enough for everyone's need, but not for everyone's greed.", 
    author: "Sunderlal Bahuguna",
    role: "Chipko Movement Leader"
  },
  { 
    text: "At GK Traders, every product we sell is a promise to the planet — small changes today create a greener tomorrow.", 
    author: "GK Traders",
    role: "🌿 Our Promise to You",
    isCompany: true
  },
];

export default function EcoQuotes() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % quotes.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const quote = quotes[currentIndex];

  return (
    <div className="bg-cream border-y-4 border-leaf py-16 px-4 relative overflow-hidden">
      {/* Background watermark logo */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Image 
          src="/logo.jpg" 
          alt="" 
          width={300} 
          height={300} 
          className="opacity-[0.04] mix-blend-multiply select-none pointer-events-none"
          aria-hidden="true"
        />
      </div>

      <div className="max-w-3xl mx-auto text-center relative z-10">
        <h2 className="text-sm uppercase tracking-widest text-leaf font-bold mb-8">
          ✦ Words of Wisdom ✦
        </h2>
        
        <div className="relative min-h-[160px] flex items-center justify-center">
          {quotes.map((q, index) => (
            <div 
              key={index}
              className={`absolute w-full transition-opacity duration-1000 ${
                index === currentIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              <p className="font-heading text-xl md:text-2xl lg:text-3xl text-darkforest font-medium italic mb-6 leading-relaxed">
                <FaQuoteLeft className="inline text-leaf/50 text-sm mr-2 align-top" />
                {q.text}
                <FaQuoteRight className="inline text-leaf/50 text-sm ml-2 align-top" />
              </p>
              <div className="flex flex-col items-center gap-1">
                {q.isCompany ? (
                  <div className="flex items-center gap-2">
                    <Image src="/logo.jpg" alt="GK" width={28} height={28} className="rounded mix-blend-multiply" />
                    <span className="font-bold text-forest text-base">{q.author}</span>
                  </div>
                ) : (
                  <span className="font-bold text-forest text-base">— {q.author}</span>
                )}
                <span className={`text-xs tracking-wider uppercase ${q.isCompany ? 'text-leaf font-bold' : 'text-sand'}`}>
                  {q.role}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex justify-center gap-2 mt-8">
          {quotes.map((q, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded-full transition-all ${
                index === currentIndex 
                  ? q.isCompany ? 'bg-forest w-8' : 'bg-leaf w-6' 
                  : 'bg-sand/50 w-2'
              }`}
              aria-label={`Quote by ${q.author}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
