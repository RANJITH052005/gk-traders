'use client';
import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FaLeaf, FaShoppingCart, FaBolt, FaCheck, FaImages } from 'react-icons/fa';
import { useCart } from '@/context/CartContext';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const router = useRouter();
  const [added, setAdded] = useState(false);
  const [activeView, setActiveView] = useState(0); // 0: Eco BG, 1: White BG

  const ecoImage = product.images?.[0]?.url || product.image;
  const whiteImage = product.images?.[1]?.url || product.image;
  const currentDisplayImage = activeView === 1 ? whiteImage : ecoImage;

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({ ...product, image: currentDisplayImage }, 1, true);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleBuyNow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({ ...product, image: currentDisplayImage }, 1, true);
    router.push('/checkout');
  };

  const switchView = (e, index) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveView(index);
  };

  return (
    <div className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden border border-sand/40 relative flex flex-col hover:-translate-y-1">
      {/* Eco Badge */}
      <div className="absolute top-3 left-3 z-10 bg-forest/90 text-cream text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm shadow-sm pointer-events-none">
        <FaLeaf size={11} className="text-leaf" /> Eco
      </div>

      {/* Active View Label Indicator */}
      <div className="absolute top-3 right-3 z-10 bg-darkforest/80 text-cream text-[10px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-sm shadow-sm pointer-events-none">
        {activeView === 1 ? '⚪ White Studio BG' : '🌿 Eco Nature BG'}
      </div>

      {/* Product Image */}
      <Link 
        href={`/products/${product.slug || product.id}`} 
        className="block relative aspect-square overflow-hidden bg-white"
      >
        {currentDisplayImage ? (
          <Image 
            src={currentDisplayImage} 
            alt={product.name}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-sand">No Image</div>
        )}

        {/* 2-Angle Quick Switcher Pills on Image */}
        {product.images && product.images.length > 1 && (
          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1.5 bg-black/50 backdrop-blur-xs p-1 rounded-full opacity-90 group-hover:opacity-100 transition-opacity">
            <button
              type="button"
              onClick={(e) => switchView(e, 0)}
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full transition-all cursor-pointer ${
                activeView === 0
                  ? 'bg-forest text-cream shadow-xs'
                  : 'text-cream/80 hover:text-white'
              }`}
              title="View with Eco Nature Background"
            >
              Eco BG
            </button>
            <button
              type="button"
              onClick={(e) => switchView(e, 1)}
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full transition-all cursor-pointer ${
                activeView === 1
                  ? 'bg-white text-darkforest shadow-xs'
                  : 'text-cream/80 hover:text-white'
              }`}
              title="View with Plain White Studio Background"
            >
              White BG
            </button>
          </div>
        )}
      </Link>
      
      {/* Product Details */}
      <div className="p-5 flex flex-col flex-grow">
        {product.category && (
          <div className="text-[11px] font-bold uppercase tracking-wider text-leaf mb-1">
            {product.category}
          </div>
        )}

        <Link href={`/products/${product.slug || product.id}`}>
          <h3 className="font-heading font-semibold text-lg text-darkforest mb-2 line-clamp-2 group-hover:text-forest transition-colors">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-gray-600 mb-4 line-clamp-2 leading-relaxed">
          {product.description}
        </p>
        
        {/* Pricing */}
        <div className="mt-auto pt-3 border-t border-sand/20 flex items-center justify-between mb-4">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-2">
              <span className="font-bold text-2xl text-darkforest">₹{product.price}</span>
              {product.compare_at_price && (
                <span className="text-sm text-gray-400 line-through">₹{product.compare_at_price}</span>
              )}
            </div>
            {product.pricingNote && (
              <span className="text-[11px] font-bold text-leaf mt-0.5">
                {product.pricingNote}
              </span>
            )}
          </div>
          <span className="text-xs font-semibold text-forest bg-lightaccent/70 px-2.5 py-1 rounded-full border border-forest/10 self-start mt-1">
            + ₹59 Delivery
          </span>
        </div>
        
        {/* Amazon-Style Action Buttons: Add to Cart and Buy Now ONLY */}
        <div className="space-y-2">
          {/* Add to Cart */}
          <button
            type="button"
            onClick={handleAddToCart}
            className={`w-full py-2.5 px-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-xs hover:shadow-md transform active:scale-98 text-sm cursor-pointer ${
              added
                ? 'bg-leaf text-white'
                : 'bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111]'
            }`}
          >
            {added ? (
              <>
                <FaCheck size={14} /> Added to Cart
              </>
            ) : (
              <>
                <FaShoppingCart size={15} /> Add to Cart
              </>
            )}
          </button>

          {/* Buy Now */}
          <button
            type="button"
            onClick={handleBuyNow}
            className="w-full bg-[#FFA41C] hover:bg-[#FA8900] text-[#0F1111] py-2.5 px-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-xs hover:shadow-md transform active:scale-98 text-sm cursor-pointer"
          >
            <FaBolt size={14} /> Buy Now
          </button>
        </div>
      </div>
    </div>
  );
}
