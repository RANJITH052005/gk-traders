'use client';
import { FaWhatsapp } from 'react-icons/fa';

export default function WhatsAppButton() {
  const message = encodeURIComponent("Hi GK Traders! I'm interested in your eco-friendly products.");
  
  return (
    <a
      href={`https://wa.me/919841202464?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group flex items-center justify-center animate-bounce"
      aria-label="Chat with us on WhatsApp"
    >
      <FaWhatsapp size={28} />
      <span className="absolute right-full mr-4 bg-darkforest text-cream text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
        Chat with us on WhatsApp
      </span>
    </a>
  );
}

