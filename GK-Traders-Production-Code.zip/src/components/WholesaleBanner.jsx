'use client';

import Link from 'next/link';
import { FaBoxes, FaWhatsapp, FaArrowRight, FaLeaf } from 'react-icons/fa';

export default function WholesaleBanner() {
  return (
    <section className="py-12 bg-darkforest text-cream relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-gradient-to-r from-forest/80 to-leaf/30 rounded-3xl p-8 sm:p-12 border border-leaf/30 flex flex-col lg:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="max-w-2xl text-center lg:text-left">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-leaf mb-3 bg-darkforest/60 px-3.5 py-1.5 rounded-full border border-leaf/20">
              <FaBoxes size={12} /> B2B & Corporate Services
            </div>
            <h3 className="text-2xl sm:text-3xl font-heading font-bold text-cream mb-3">
              Corporate Gifting & Bulk Wholesale Orders
            </h3>
            <p className="text-lightaccent/90 text-sm sm:text-base leading-relaxed">
              Elevate your brand with sustainable corporate welcome kits, custom-engraved bamboo bottles, zero-waste office hampers, and bulk eco supplies. Direct factory wholesale pricing available.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            <Link
              href="/contact"
              className="w-full sm:w-auto text-center bg-cream hover:bg-white text-forest font-bold px-6 py-3.5 rounded-2xl text-sm transition-all shadow-md hover:scale-105"
            >
              Request Wholesale Quote
            </Link>
            <a
              href="https://wa.me/919841202464?text=Hi%20GK%20Traders!%20I%20am%20interested%20in%20bulk%20wholesale%20/%20corporate%20gifting%20pricing."
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto text-center inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold px-6 py-3.5 rounded-2xl text-sm transition-all shadow-md hover:scale-105"
            >
              <FaWhatsapp size={16} /> Bulk Chat (+91 9841202464)
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
