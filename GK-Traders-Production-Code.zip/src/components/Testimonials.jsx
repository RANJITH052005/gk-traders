'use client';

import { FaStar, FaQuoteLeft, FaCheckCircle, FaLeaf } from 'react-icons/fa';

const TESTIMONIALS = [
  {
    id: 1,
    name: 'Priya Sundaram',
    location: 'Anna Nagar, Chennai',
    product: 'Eco-Friendly Glass Bottle (330ml) Kids',
    rating: 5,
    date: '2 weeks ago',
    comment:
      'My 6-year-old daughter loves the Blossom Pink bottle! The silicone rabbit sleeve gives a solid grip, and knowing it is 100% BPA-free borosilicate glass gives me peace of mind when packing school water.',
    verified: true,
  },
  {
    id: 2,
    name: 'Rajesh Sharma',
    location: 'Indiranagar, Bangalore',
    product: 'Eco-Friendly Bamboo Bottle (750ml)',
    rating: 5,
    date: '3 weeks ago',
    comment:
      'The double-wall insulation is impressive. Kept my herbal tea hot throughout my 8-hour workday. The natural bamboo casing has an authentic, premium touch that plastic bottles can never match.',
    verified: true,
  },
  {
    id: 3,
    name: 'Dr. Ananya Iyer',
    location: 'R.S. Puram, Coimbatore',
    product: 'Eco-Friendly Bamboo Toothbrush & Tongue Cleaner',
    rating: 5,
    date: '1 month ago',
    comment:
      'As a dental professional, I appreciate the charcoal bristles and ergonomic bamboo curve. The tongue scraper is wonderfully smooth with zero harsh edges. Ordered 4 sets for my family!',
    verified: true,
  },
  {
    id: 4,
    name: 'Karthik V.',
    location: 'Madhapur, Hyderabad',
    product: 'Eco-Friendly Coconut Vessel Scrub (Box of 5)',
    rating: 5,
    date: '1 month ago',
    comment:
      'Swapped out synthetic yellow/green sponges for these coir scrubbers. They cut through oil on cast-iron and non-stick cookware effortlessly and never smell funky. Plus, they compost right in my garden pots!',
    verified: true,
  },
];

export default function Testimonials() {
  return (
    <section className="py-16 sm:py-20 bg-cream/50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-leaf mb-3 bg-leaf/10 px-3.5 py-1.5 rounded-full border border-forest/10">
            <FaLeaf size={11} /> Real Customer Stories
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-4">
            Loved by Thousands of Conscious Homes
          </h2>
          <p className="text-gray-600 text-base sm:text-lg">
            See why families across India choose GK Traders for their plastic-free daily essentials.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-3xl p-6 shadow-sm border border-sand/40 flex flex-col justify-between hover:shadow-md transition-all hover:-translate-y-1"
            >
              <div>
                {/* Rating Stars & Quote Icon */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex text-[#FFA41C] gap-1">
                    {[...Array(t.rating)].map((_, i) => (
                      <FaStar key={i} size={14} />
                    ))}
                  </div>
                  <FaQuoteLeft className="text-sand/40 text-xl" />
                </div>

                {/* Comment */}
                <p className="text-gray-700 text-sm leading-relaxed mb-6 italic">
                  &ldquo;{t.comment}&rdquo;
                </p>
              </div>

              {/* Author & Product Info */}
              <div className="pt-4 border-t border-sand/30">
                <div className="flex items-center justify-between">
                  <h4 className="font-heading font-bold text-darkforest text-sm">
                    {t.name}
                  </h4>
                  {t.verified && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-leaf">
                      <FaCheckCircle size={10} /> Verified Buyer
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-0.5">{t.location}</p>
                <div className="mt-2 text-[11px] text-forest font-medium bg-forest/5 px-2.5 py-1 rounded-lg truncate">
                  Purchased: {t.product}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
