import Link from 'next/link';
import Image from 'next/image';
import { FaWhatsapp, FaLeaf } from 'react-icons/fa';

export default function HeroBanner() {
  return (
    <div className="relative bg-gradient-to-r from-forest to-leaf text-cream py-20 sm:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Watermarks */}
      {/* Center watermark (500x500 opacity-[0.15]) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <Image 
          src="/logo.jpg" 
          alt="" 
          width={500} 
          height={500} 
          className="opacity-[0.15] mix-blend-multiply pointer-events-none select-none"
          priority
        />
      </div>

      {/* Top-left watermark (250x250 opacity-[0.10] rotate-[-15deg]) */}
      <div className="absolute -top-10 -left-10 pointer-events-none select-none">
        <Image 
          src="/logo.jpg" 
          alt="" 
          width={250} 
          height={250} 
          className="opacity-[0.10] rotate-[-15deg] mix-blend-multiply pointer-events-none select-none"
        />
      </div>

      {/* Bottom-right watermark (300x300 opacity-[0.10] rotate-[15deg]) */}
      <div className="absolute -bottom-10 -right-10 pointer-events-none select-none">
        <Image 
          src="/logo.jpg" 
          alt="" 
          width={300} 
          height={300} 
          className="opacity-[0.10] rotate-[15deg] mix-blend-multiply pointer-events-none select-none"
        />
      </div>

      <div className="relative max-w-4xl mx-auto text-center z-10">
        {/* Centered GK logo (80x80 rounded-lg mix-blend-multiply) */}
        <div className="flex justify-center mb-6">
          <Image 
            src="/logo.jpg" 
            alt="GK Traders Logo" 
            width={80} 
            height={80} 
            className="rounded-lg mix-blend-multiply shadow-md"
            priority
          />
        </div>

        {/* Eco badge pill: '100% Eco-Friendly Products' with FaLeaf */}
        <div className="inline-flex items-center gap-2 bg-cream/20 border border-cream/30 text-cream px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold mb-6 backdrop-blur-sm shadow-sm">
          <FaLeaf className="text-cream" />
          <span>100% Eco-Friendly Products</span>
        </div>
        
        {/* h1: 'Sustainable Living Starts Here' with font-heading text-4xl sm:text-5xl md:text-6xl */}
        <h1 className="font-heading font-bold text-4xl sm:text-5xl md:text-6xl text-cream mb-6 leading-tight drop-shadow-sm">
          Sustainable Living Starts Here
        </h1>
        
        {/* Subtitle paragraph about eco-friendly products */}
        <p className="text-base sm:text-lg md:text-xl text-cream/95 max-w-2xl mx-auto mb-8 font-light leading-relaxed">
          Crafted from nature, designed for conscious homes. Explore our zero-plastic alternatives and place orders directly with us on WhatsApp or through our online store.
        </p>

        {/* Two CTA buttons: 'Shop Now' and 'WhatsApp Us' */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <Link 
            href="/products" 
            className="w-full sm:w-auto flex-1 bg-cream text-forest font-bold px-8 py-3.5 rounded-full hover:bg-white hover:shadow-lg transition-all text-center text-base"
          >
            Shop Now
          </Link>
          <a 
            href="https://wa.me/919841202464" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 border-2 border-cream text-cream font-bold px-8 py-3.5 rounded-full hover:bg-cream hover:text-forest transition-all text-center text-base"
          >
            <FaWhatsapp size={20} />
            <span>WhatsApp Us</span>
          </a>
        </div>
      </div>
    </div>
  );
}
