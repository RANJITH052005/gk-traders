'use client';

import { useState } from 'react';
import Link from 'next/link';
import { FaChevronDown, FaQuestionCircle, FaWhatsapp, FaLeaf } from 'react-icons/fa';

const FAQS = [
  {
    question: 'Are all GK Traders products genuinely 100% plastic-free and biodegradable?',
    answer:
      'Yes, absolutely. All our toothbrushes, tongue cleaners, combs, and scrub pads are handcrafted from 100% natural Moso bamboo and South Indian coconut coir fibers. Even our bottles use pure borosilicate glass, food-grade silicone, or 304 food-grade stainless steel with natural bamboo cladding. We never use synthetic plastics, BPA, toxic dyes, or chemical coatings.',
  },
  {
    question: 'What are your delivery charges and shipping times across India?',
    answer:
      'We charge a flat ₹59 standard delivery fee across all serviceable pincodes in India. Orders within Chennai and Tamil Nadu arrive in 2–3 business days. Metro cities (Bangalore, Mumbai, Hyderabad, Delhi) arrive in 3–5 business days, and the rest of India in 5–7 business days via top courier partners (Delhivery, BlueDart, DTDC).',
  },
  {
    question: 'Can I order directly through WhatsApp instead of using online checkout?',
    answer:
      'Yes! Every product page and shopping cart includes a 1-click "Order via WhatsApp" button. It automatically formats your selected items, quantities, and delivery address into a pre-filled WhatsApp message sent to our official team (+91 9841202464). You can pay conveniently via UPI, Google Pay, PhonePe, or Paytm.',
  },
  {
    question: 'Do you offer bulk wholesale pricing or corporate gifting customization?',
    answer:
      'Yes, we regularly cater to corporate sustainability kits, wedding return favors, eco-friendly event giveaways, and bulk retailer inquiries. We can also provide custom laser engraving and plastic-free gift packaging. Reach out to us via our Contact page or WhatsApp (+91 9841202464) for wholesale rate cards.',
  },
  {
    question: 'What is your refund and return policy if an item arrives damaged?',
    answer:
      'We stand behind every product we craft. In the rare event of transit damage or defects, simply send a photo/video to hellogktraders@gmail.com or WhatsApp (+91 9841202464) within 48 hours of delivery, and we will dispatch a free replacement or issue a full refund immediately with no hassle.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  const toggleFAQ = (idx) => {
    setOpenIndex(openIndex === idx ? -1 : idx);
  };

  return (
    <section className="py-16 sm:py-20 bg-white relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-forest mb-3 bg-forest/10 px-3.5 py-1.5 rounded-full border border-forest/10">
            <FaQuestionCircle size={12} className="text-leaf" /> Common Questions
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-gray-600 text-base sm:text-lg">
            Everything you need to know about our products, deliveries, and sustainability standards.
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-4">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="border border-sand/40 rounded-2xl overflow-hidden transition-all duration-200 bg-cream/20 hover:border-forest/40"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(index)}
                  className="w-full py-5 px-6 text-left flex items-center justify-between gap-4 font-heading font-semibold text-darkforest text-base sm:text-lg cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span>{faq.question}</span>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-transform duration-200 ${
                      isOpen ? 'bg-forest text-cream rotate-180' : 'bg-sand/30 text-darkforest'
                    }`}
                  >
                    <FaChevronDown size={12} />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-gray-700 text-sm sm:text-base leading-relaxed border-t border-sand/20">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Help box */}
        <div className="mt-12 p-6 sm:p-8 rounded-3xl bg-forest/5 border border-forest/20 text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="font-heading font-bold text-darkforest text-lg">
              Still have a question?
            </h4>
            <p className="text-sm text-gray-600 mt-0.5">
              Our Chennai support team is here to assist you anytime.
            </p>
          </div>
          <div className="flex gap-3">
            <Link
              href="/contact"
              className="px-5 py-2.5 rounded-full bg-white text-forest font-bold text-xs sm:text-sm border border-forest/30 hover:bg-forest hover:text-white transition-colors shadow-xs"
            >
              Contact Us
            </Link>
            <a
              href="https://wa.me/919841202464"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] text-white px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm hover:bg-[#20bd5a] transition-all shadow-xs"
            >
              <FaWhatsapp size={14} /> WhatsApp Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
