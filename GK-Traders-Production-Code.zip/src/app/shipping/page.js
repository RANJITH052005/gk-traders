import Link from 'next/link';
import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';

export const metadata = {
  title: 'Shipping Policy | GK Traders',
  description: 'Shipping & Delivery policy for GK Traders eco-friendly products.',
};

export default function ShippingPolicyPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 p-8 sm:p-12">
          <div className="flex items-center gap-2 text-forest font-semibold mb-3">
            <FaLeaf className="text-leaf" /> Legal & Transparency
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-6">
            Shipping & Delivery Policy
          </h1>
          <p className="text-sm text-gray-500 mb-8">Last updated: October 2026</p>

          <div className="space-y-6 text-gray-700 leading-relaxed text-sm sm:text-base">
            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">1. Shipping Coverage</h2>
              <p>
                GK Traders delivers across all serviceable pincodes in India. We use reliable courier partners (Delhivery, BlueDart, DTDC, India Post) to ensure safe, eco-friendly transit.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">2. Processing Time</h2>
              <p>
                All orders are processed and packed within <strong>24 to 48 hours</strong> of payment confirmation (excluding Sundays and national holidays).
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">3. Estimated Delivery Time</h2>
              <ul className="list-disc pl-5 space-y-1">
                <li><strong>Within Chennai / Tamil Nadu:</strong> 2 to 3 business days</li>
                <li><strong>Metro Cities (Bangalore, Mumbai, Delhi, Hyderabad, etc.):</strong> 3 to 5 business days</li>
                <li><strong>Rest of India:</strong> 5 to 7 business days</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">4. Shipping Charges</h2>
              <p>
                We charge a flat <strong>₹59.00 Standard Delivery Fee</strong> across India for every order to ensure safe handling and reliable transport.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">5. Order Tracking</h2>
              <p>
                Once your order is dispatched, you will receive tracking updates via SMS / WhatsApp. You can also contact us anytime on WhatsApp at <strong>+91 9841202464</strong> with your Order Number for real-time tracking updates.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">6. Eco-Friendly Packaging</h2>
              <p>
                To keep our pledge to Mother Earth, all orders are shipped in 100% plastic-free, recyclable cardboard boxes with paper tape and biodegradable infill.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">7. Contact Information</h2>
              <p>
                For shipping inquiries, reach out to us:
              </p>
              <ul className="list-none pl-0 mt-2 space-y-1 text-sm">
                <li><strong>GK Traders</strong></li>
                <li>Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092</li>
                <li>Email: hellogktraders@gmail.com</li>
                <li>Phone / WhatsApp: +91 9841202464</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

