'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { 
  FaEnvelope, 
  FaWhatsapp, 
  FaTrash, 
  FaSync, 
  FaLeaf, 
  FaArrowLeft, 
  FaCheckCircle, 
  FaClock, 
  FaPhoneAlt,
  FaDatabase
} from 'react-icons/fa';
import { createClient } from '@/lib/supabase/client';

export default function AdminMessagesPage() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState('checking'); // 'connected', 'paused', 'error'
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    loadAllMessages();
  }, []);

  const loadAllMessages = async () => {
    setLoading(true);
    let combined = [];

    // 1. Load local messages
    try {
      const local = JSON.parse(localStorage.getItem('gk_contact_messages') || '[]');
      combined = [...local];
    } catch (e) {
      console.warn('Could not read local storage:', e);
    }

    // 2. Try to fetch from Supabase
    try {
      const supabase = createClient();
      const { data, error } = await supabase
        .from('contact_messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        setSupabaseStatus('paused');
      } else if (data) {
        setSupabaseStatus('connected');
        // Merge without duplicates by id or timestamp+email
        const existingIds = new Set(combined.map((m) => m.id || `${m.created_at}-${m.email}`));
        data.forEach((row) => {
          const key = row.id || `${row.created_at}-${row.email}`;
          if (!existingIds.has(key)) {
            combined.push(row);
          }
        });
      }
    } catch (err) {
      setSupabaseStatus('paused');
    }

    // Sort by created_at descending
    combined.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

    setMessages(combined);
    setLoading(false);
  };

  const handleSyncSupabase = async () => {
    setSyncing(true);
    await loadAllMessages();
    setSyncing(false);
  };

  const handleDelete = (idToDelete) => {
    if (!confirm('Are you sure you want to delete this message?')) return;

    const updated = messages.filter((m) => m.id !== idToDelete);
    setMessages(updated);

    try {
      localStorage.setItem('gk_contact_messages', JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }

    // Also attempt delete from Supabase if connected
    try {
      const supabase = createClient();
      supabase.from('contact_messages').delete().eq('id', idToDelete);
    } catch (e) {
      console.warn(e);
    }
  };

  const handleClearAll = () => {
    if (!confirm('Clear all stored messages from this browser?')) return;
    localStorage.removeItem('gk_contact_messages');
    setMessages([]);
  };

  const filteredMessages = filter === 'All' 
    ? messages 
    : messages.filter((m) => m.inquiry_type === filter || m.inquiryType === filter);

  return (
    <div className="min-h-screen bg-cream py-10 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={650} 
          height={650} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Navigation & Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <Link 
              href="/contact" 
              className="inline-flex items-center gap-2 text-xs font-semibold text-forest hover:text-darkforest mb-2 transition-colors"
            >
              <FaArrowLeft size={11} /> Back to Contact Form
            </Link>
            <div className="flex items-center gap-2">
              <span className="text-leaf text-xs font-bold uppercase tracking-widest bg-leaf/15 px-3 py-1 rounded-full flex items-center gap-1.5 border border-forest/10">
                <FaDatabase size={11} /> Admin Dashboard
              </span>
              <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                supabaseStatus === 'connected' 
                  ? 'bg-green-100 text-green-800 border border-green-200' 
                  : 'bg-amber-100 text-amber-800 border border-amber-200'
              }`}>
                <span className={`w-2 h-2 rounded-full ${supabaseStatus === 'connected' ? 'bg-green-600' : 'bg-amber-500 animate-pulse'}`}></span>
                {supabaseStatus === 'connected' ? 'Supabase Online' : 'Supabase Restoring (Local Active)'}
              </span>
            </div>
            <h1 className="text-3xl font-heading font-bold text-darkforest mt-2">
              Customer Feedback & Inquiries
            </h1>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSyncSupabase}
              disabled={syncing}
              className="inline-flex items-center gap-2 bg-white text-forest border border-forest/30 hover:bg-forest/5 font-semibold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition-all cursor-pointer"
            >
              <FaSync className={syncing ? 'animate-spin' : ''} />
              <span>{syncing ? 'Checking...' : 'Refresh / Sync'}</span>
            </button>

            {messages.length > 0 && (
              <button
                type="button"
                onClick={handleClearAll}
                className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-700 font-medium px-3.5 py-2.5 rounded-xl text-xs border border-red-200 transition-colors cursor-pointer"
              >
                <FaTrash size={12} />
                <span>Clear Local</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2">Filter:</span>
          {['All', 'General Inquiry', 'Bulk / Wholesale Orders', 'Product Question', 'Feedback'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`text-xs px-3.5 py-1.5 rounded-full font-medium transition-all cursor-pointer ${
                filter === f
                  ? 'bg-forest text-cream shadow-xs'
                  : 'bg-white text-gray-700 border border-sand/50 hover:bg-cream'
              }`}
            >
              {f}
            </button>
          ))}
          <span className="ml-auto text-xs text-gray-500 font-medium">
            Total: <strong>{filteredMessages.length}</strong> {filteredMessages.length === 1 ? 'message' : 'messages'}
          </span>
        </div>

        {/* Content Area */}
        {loading ? (
          <div className="bg-white rounded-3xl p-16 text-center shadow-xs border border-sand/40">
            <div className="w-10 h-10 border-4 border-forest border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 text-sm">Loading feedback messages...</p>
          </div>
        ) : filteredMessages.length === 0 ? (
          <div className="bg-white rounded-3xl p-16 text-center shadow-xs border border-sand/40 max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-cream text-forest flex items-center justify-center mx-auto mb-4 border border-sand/40">
              <FaEnvelope size={26} className="text-leaf" />
            </div>
            <h3 className="text-xl font-heading font-bold text-darkforest mb-2">
              No Messages Yet
            </h3>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              When customers submit questions or feedback from the contact form, their entries will show up here immediately with 1-click WhatsApp reply links!
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] font-bold px-6 py-3 rounded-xl text-sm transition-all shadow-sm"
            >
              <span>Test Contact Form</span>
              <span>&rarr;</span>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMessages.map((msg, index) => {
              const formattedDate = msg.created_at
                ? new Date(msg.created_at).toLocaleString('en-IN', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  })
                : 'Just now';

              const phoneClean = msg.phone ? msg.phone.replace(/[^0-9]/g, '') : '';
              const waReplyLink = phoneClean 
                ? `https://wa.me/${phoneClean.startsWith('91') ? phoneClean : '91' + phoneClean}?text=${encodeURIComponent(`Hi ${msg.name}! Thanks for reaching out to GK Traders regarding "${msg.inquiry_type || msg.inquiryType || 'your inquiry'}". How can we assist you?`)}`
                : null;

              return (
                <div
                  key={msg.id || index}
                  className="bg-white rounded-2xl p-6 sm:p-7 shadow-xs border border-sand/40 hover:shadow-md transition-shadow relative overflow-hidden"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-sand/20">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-heading font-bold text-lg text-darkforest">
                          {msg.name}
                        </h3>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-forest bg-lightaccent/40 px-2.5 py-0.5 rounded-full border border-forest/10">
                          {msg.inquiry_type || msg.inquiryType || 'Inquiry'}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 mt-1">
                        <a href={`mailto:${msg.email}`} className="hover:text-forest underline">
                          {msg.email}
                        </a>
                        {msg.phone && (
                          <span className="flex items-center gap-1 font-medium text-darkforest">
                            <FaPhoneAlt size={10} className="text-leaf" /> {msg.phone}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <FaClock size={12} />
                      <span>{formattedDate}</span>
                    </div>
                  </div>

                  {/* Message Body */}
                  <p className="text-gray-700 text-sm sm:text-base leading-relaxed whitespace-pre-line mb-6 bg-cream/30 p-4 rounded-xl border border-sand/30">
                    {msg.message}
                  </p>

                  {/* Reply actions */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <div className="flex items-center gap-2">
                      {waReplyLink ? (
                        <a
                          href={waReplyLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white text-xs font-bold py-2 px-4 rounded-xl shadow-xs hover:shadow-md transition-all"
                        >
                          <FaWhatsapp size={15} />
                          <span>Reply on WhatsApp</span>
                        </a>
                      ) : (
                        <span className="text-xs text-gray-400 italic">No phone provided</span>
                      )}

                      <a
                        href={`mailto:${msg.email}?subject=${encodeURIComponent(`GK Traders Reply: ${msg.inquiry_type || msg.inquiryType || 'Your Inquiry'}`)}`}
                        className="inline-flex items-center gap-1.5 bg-forest hover:bg-darkforest text-cream text-xs font-bold py-2 px-4 rounded-xl shadow-xs transition-all"
                      >
                        <FaEnvelope size={12} />
                        <span>Reply by Email</span>
                      </a>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDelete(msg.id)}
                      className="text-gray-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50 transition-colors text-xs flex items-center gap-1 cursor-pointer"
                      title="Delete"
                    >
                      <FaTrash size={12} />
                      <span className="hidden sm:inline">Delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
