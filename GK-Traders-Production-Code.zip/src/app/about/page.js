import Link from 'next/link';
import Image from 'next/image';
import { FaLeaf, FaHeart, FaGlobeAmericas, FaRecycle, FaTruck, FaShieldAlt } from 'react-icons/fa';

export const metadata = {
  title: 'About Us | GK Traders - Eco-Friendly Products Chennai',
  description: 'Learn about GK Traders in Chennai. Discover our story, mission, and commitment to 100% eco-friendly, zero-plastic sustainable living.',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-cream relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={700} 
          height={700} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      {/* Hero Header with Organic Gradient and Watermarks */}
      <div className="relative bg-gradient-to-r from-forest to-leaf text-cream py-20 px-4 sm:px-6 lg:px-8 text-center overflow-hidden">
        {/* Subtle Watermarks */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
          <Image 
            src="/logo.jpg" 
            alt="" 
            width={400} 
            height={400} 
            className="opacity-[0.12] mix-blend-multiply pointer-events-none select-none"
          />
        </div>

        <div className="relative max-w-4xl mx-auto z-10">
          <div className="flex justify-center mb-5">
            <Image 
              src="/logo.jpg" 
              alt="GK Traders Logo" 
              width={70} 
              height={70} 
              className="rounded-2xl mix-blend-multiply shadow-md bg-white/20 p-1"
            />
          </div>

          <div className="inline-flex items-center gap-2 bg-cream/20 border border-cream/30 text-cream px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold mb-4 backdrop-blur-xs">
            <FaLeaf className="text-leaf" />
            <span>Handcrafted with Care in Chennai, India</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold mb-4 drop-shadow-xs">
            About GK Traders
          </h1>

          <p className="text-base sm:text-lg lg:text-xl text-cream/95 font-light max-w-2xl mx-auto leading-relaxed">
            Leading the green revolution from Chennai with handcrafted, 100% plastic-free, everyday essentials for conscious homes.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 relative z-10">
        {/* Our Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20 sm:mb-24">
          {/* Left Column: Vision & Story Text */}
          <div>
            <div className="inline-flex items-center gap-2 text-forest font-bold text-xs uppercase tracking-wider mb-3 bg-lightaccent/40 px-3.5 py-1.5 rounded-full border border-forest/10">
              <FaLeaf className="text-leaf" /> Our Story & Vision
            </div>
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-6">
              Pioneering Sustainable Living for Every Home
            </h2>
            <div className="space-y-4 text-gray-700 leading-relaxed text-sm sm:text-base">
              <p>
                GK Traders was founded in Virugambakkam, Chennai, with a singular mission: to make pure, eco-friendly living accessible, practical, and affordable for every Indian family. Every single day, billions of single-use plastic products are discarded after only minutes of use, clogging waterways and polluting our soil for centuries.
              </p>
              <p>
                We envisioned a better way. By harnessing naturally regenerative, biodegradable materials such as Moso bamboo, organic coconut coir, and pure borosilicate glass, we replace plastic toothbrushes, combs, scrub pads, and drinkware with sustainable alternatives that naturally return to the Earth.
              </p>
              <p>
                Our vision extends beyond products — it is about inspiring daily habits of mindfulness and responsible consumption. We take immense pride in ensuring every order is packed plastic-free and delivered across India with love and care.
              </p>
            </div>
          </div>

          {/* Right Column: 2x2 Grid Stats */}
          <div className="bg-white/80 backdrop-blur-xs p-6 sm:p-8 rounded-3xl border border-sand/50 shadow-sm">
            <div className="grid grid-cols-2 gap-4 sm:gap-6">
              <div className="bg-cream/40 p-6 rounded-2xl text-center border border-sand/30 flex flex-col items-center justify-center">
                <FaGlobeAmericas className="text-3xl sm:text-4xl text-forest mb-3" />
                <h3 className="font-heading font-bold text-2xl sm:text-3xl text-darkforest">100%</h3>
                <p className="text-xs sm:text-sm text-gray-600 font-medium mt-1">Eco-Friendly</p>
              </div>

              <div className="bg-cream/40 p-6 rounded-2xl text-center border border-sand/30 flex flex-col items-center justify-center">
                <FaRecycle className="text-3xl sm:text-4xl text-leaf mb-3" />
                <h3 className="font-heading font-bold text-2xl sm:text-3xl text-darkforest">Zero</h3>
                <p className="text-xs sm:text-sm text-gray-600 font-medium mt-1">Plastic Waste</p>
              </div>

              <div className="bg-cream/40 p-6 rounded-2xl text-center border border-sand/30 flex flex-col items-center justify-center">
                <FaLeaf className="text-3xl sm:text-4xl text-forest mb-3" />
                <h3 className="font-heading font-bold text-2xl sm:text-3xl text-darkforest">100%</h3>
                <p className="text-xs sm:text-sm text-gray-600 font-medium mt-1">Natural Materials</p>
              </div>

              <div className="bg-cream/40 p-6 rounded-2xl text-center border border-sand/30 flex flex-col items-center justify-center">
                <FaTruck className="text-3xl sm:text-4xl text-forest mb-3" />
                <h3 className="font-heading font-bold text-2xl sm:text-3xl text-darkforest">₹59</h3>
                <p className="text-xs sm:text-sm text-gray-600 font-medium mt-1">Flat Delivery</p>
              </div>
            </div>
          </div>
        </div>

        {/* Why Go Eco-Friendly Section */}
        <div className="mb-20 sm:mb-24">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-leaf text-xs sm:text-sm font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 mb-2">
              <FaLeaf /> Make The Difference
            </span>
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest">
              Why Go Eco-Friendly?
            </h2>
            <p className="text-gray-600 text-sm sm:text-base mt-3">
              Simple everyday swaps create a massive positive ripple effect for the planet and your family.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-3xl border-t-4 border-leaf shadow-sm hover:shadow-md transition-shadow border-x border-b border-sand/30">
              <div className="w-12 h-12 rounded-2xl bg-leaf/15 flex items-center justify-center text-leaf mb-5">
                <FaRecycle size={22} />
              </div>
              <h3 className="font-heading font-bold text-xl text-darkforest mb-3">
                Reduce Ocean Plastic
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Billions of plastic toothbrushes and nylon sponges end up in our waterways each year. Switching to renewable bamboo and coconut fiber eliminates non-biodegradable waste at the source.
              </p>
            </div>

            <div className="bg-white p-8 rounded-3xl border-t-4 border-forest shadow-sm hover:shadow-md transition-shadow border-x border-b border-sand/30">
              <div className="w-12 h-12 rounded-2xl bg-forest/15 flex items-center justify-center text-forest mb-5">
                <FaHeart size={22} />
              </div>
              <h3 className="font-heading font-bold text-xl text-darkforest mb-3">
                Healthier for You
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Conventional plastic kitchenware and hygiene items leach toxic BPA, phthalates, and microplastics. Our products are 100% natural, non-toxic, and safe for everyone in your household.
              </p>
            </div>

            <div className="bg-white p-8 rounded-3xl border-t-4 border-sand shadow-sm hover:shadow-md transition-shadow border-x border-b border-sand/30">
              <div className="w-12 h-12 rounded-2xl bg-sand/30 flex items-center justify-center text-darkforest mb-5">
                <FaGlobeAmericas size={22} />
              </div>
              <h3 className="font-heading font-bold text-xl text-darkforest mb-3">
                Support Sustainability
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                We utilize fast-growing, carbon-absorbing bamboo and upcycled agricultural by-products, promoting ethical harvesting and supporting local artisan communities in India.
              </p>
            </div>
          </div>
        </div>

        {/* Promise CTA */}
        <div className="bg-white/80 backdrop-blur-xs rounded-3xl p-8 sm:p-14 text-center max-w-4xl mx-auto border border-leaf/30 shadow-sm relative overflow-hidden">
          <div className="w-16 h-16 rounded-full bg-forest/10 flex items-center justify-center text-forest mx-auto mb-4">
            <FaLeaf size={28} className="text-leaf" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest mb-4">
            Our Green Commitment
          </h2>
          <blockquote className="text-gray-700 text-base sm:text-lg mb-8 max-w-2xl mx-auto italic font-normal leading-relaxed">
            &ldquo;At GK Traders, we believe that small conscious choices each day create monumental changes for our planet. Every bamboo toothbrush, glass bottle, and coconut scrub is our promise for a cleaner, greener tomorrow.&rdquo;
          </blockquote>
          <div>
            <Link
              href="/products"
              className="inline-flex items-center gap-2 bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] font-bold px-8 py-3.5 rounded-full shadow-md text-base hover:scale-105 transform transition-all"
            >
              <span>Explore Our Collection</span>
              <span>&rarr;</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
