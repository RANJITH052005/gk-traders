import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';

export const metadata = {
  title: 'Refund & Cancellation Policy | GK Traders',
  description: 'Return, refund, and cancellation policy for GK Traders.',
};

export default function RefundPolicyPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 p-8 sm:p-12">
          <div className="flex items-center gap-2 text-forest font-semibold mb-3">
            <FaLeaf className="text-leaf" /> Customer Satisfaction
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-6">
            Refund & Cancellation Policy
          </h1>
          <p className="text-sm text-gray-500 mb-8">Last updated: October 2026</p>

          <div className="space-y-6 text-gray-700 leading-relaxed text-sm sm:text-base">
            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">1. Cancellation Policy</h2>
              <p>
                You may request order cancellation within <strong>12 hours</strong> of placing the order or before the parcel has been handed over to the courier partner, whichever is earlier. Once dispatched, an order cannot be canceled.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">2. Return & Replacement Eligibility</h2>
              <p>
                We accept returns and replacements within <strong>7 days</strong> from the delivery date only under the following conditions:
              </p>
              <ul className="list-disc pl-5 mt-2 space-y-1">
                <li>Item arrived damaged, defective, or broken during transit.</li>
                <li>Wrong item or incorrect quantity was delivered.</li>
                <li>The product is in its original unused condition with all original packaging intact.</li>
              </ul>
              <p className="mt-2 text-xs text-gray-500 italic">
                * Note: Due to hygiene reasons, personal care products such as bamboo toothbrushes and tongue cleaners cannot be returned once opened/used unless received defective.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">3. How to Request a Return / Refund</h2>
              <p>
                To raise a return or refund request:
              </p>
              <ol className="list-decimal pl-5 mt-2 space-y-1">
                <li>Message us on WhatsApp at <strong>+91 9841202464</strong> or email <strong>hellogktraders@gmail.com</strong>.</li>
                <li>Include your Order Reference number and clear photos/unboxing videos of the damaged/incorrect product.</li>
                <li>Our support team will verify and resolve your request within 24 to 48 hours.</li>
              </ol>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">4. Refund Process & Timelines</h2>
              <p>
                Once your return is inspected and approved, a full refund will be processed back to your original payment method (Bank account, UPI, or Credit/Debit card used via Razorpay). Refunds typically reflect in your account within <strong>5 to 7 business days</strong> as per standard banking processing cycles.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">5. Contact Information</h2>
              <p>
                For any questions regarding returns or refunds:
              </p>
              <ul className="list-none pl-0 mt-2 space-y-1 text-sm">
                <li><strong>GK Traders</strong></li>
                <li>Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092</li>
                <li>Email: hellogktraders@gmail.com</li>
                <li>WhatsApp: +91 9841202464</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

