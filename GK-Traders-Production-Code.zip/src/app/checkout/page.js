'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { 
  FaWhatsapp, 
  FaLock, 
  FaShieldAlt, 
  FaTruck, 
  FaLeaf, 
  FaArrowLeft, 
  FaCreditCard,
  FaCheckCircle
} from 'react-icons/fa';

export default function CheckoutPage() {
  const router = useRouter();
  const cartContext = useCart();
  const authContext = useAuth();

  const cartItems = cartContext?.cartItems || [];
  const cartTotal = cartContext?.cartTotal ?? cartItems.reduce((acc, item) => acc + ((item.product?.price || 0) * item.quantity), 0);
  const clearCart = cartContext?.clearCart || (() => {});
  const loading = cartContext?.loading || false;
  const user = authContext?.user || null;

  const deliveryFee = 59;
  const totalAmount = cartTotal + (cartItems.length > 0 ? deliveryFee : 0);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    if (user?.email && !formData.email) {
      setFormData((prev) => ({
        ...prev,
        email: user.email,
        fullName: prev.fullName || user.user_metadata?.full_name || '',
      }));
    }
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.fullName.trim()) errors.fullName = 'Full Name is required';
    if (!formData.email.trim()) {
      errors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^[0-9+ ]{10,14}$/.test(formData.phone.replace(/[\s-]/g, ''))) {
      errors.phone = 'Please enter a valid 10-digit phone number';
    }
    if (!formData.address.trim()) errors.address = 'Street address is required';
    if (!formData.city.trim()) errors.city = 'City is required';
    if (!formData.state.trim()) errors.state = 'State is required';
    if (!formData.pincode.trim()) {
      errors.pincode = 'Pincode is required';
    } else if (!/^\d{6}$/.test(formData.pincode.trim())) {
      errors.pincode = 'Please enter a valid 6-digit Indian PIN code';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      if (typeof window !== 'undefined' && window.Razorpay) {
        resolve(true);
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.async = true;
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleRazorpayPayment = async (e) => {
    if (e) e.preventDefault();

    if (!validateForm()) {
      const firstError = Object.values(formErrors)[0] || 'Please complete all required fields';
      alert(`Please fill all required shipping information.\n\n${firstError}`);
      return;
    }

    if (cartItems.length === 0) {
      alert('Your cart is empty. Please add items to checkout.');
      router.push('/products');
      return;
    }

    setIsProcessing(true);

    try {
      const isLoaded = await loadRazorpayScript();
      if (!isLoaded) {
        alert('Could not load Razorpay payment SDK. Please check your network connection or use WhatsApp Ordering.');
        setIsProcessing(false);
        return;
      }

      const amountInPaise = (cartTotal + deliveryFee) * 100;
      const razorpayKey = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || 'rzp_test_Tgh1Jox0hHJ6qG';

      const options = {
        key: razorpayKey,
        amount: amountInPaise,
        currency: 'INR',
        name: 'GK Traders',
        description: 'Eco-Friendly Products',
        image: '/logo.jpg',
        prefill: {
          name: formData.fullName,
          email: formData.email,
          contact: formData.phone,
        },
        notes: {
          address: `${formData.address}, ${formData.city}, ${formData.state} - ${formData.pincode}`,
        },
        theme: {
          color: '#2d6a4f',
        },
        handler: function (response) {
          alert(`Payment Successful!\nPayment ID: ${response.razorpay_payment_id}\n\nThank you for choosing eco-friendly products with GK Traders!`);
          clearCart();
          router.push('/');
        },
        modal: {
          ondismiss: function () {
            setIsProcessing(false);
          },
        },
      };

      const razorpayInstance = new window.Razorpay(options);
      razorpayInstance.on('payment.failed', function (response) {
        alert(`Payment failed: ${response.error?.description || 'Payment was not completed. Please try again.'}`);
        setIsProcessing(false);
      });

      razorpayInstance.open();
    } catch (err) {
      console.error('Razorpay initialization error:', err);
      alert('Unable to launch Razorpay. You can also complete your order directly through WhatsApp.');
      setIsProcessing(false);
    }
  };

  const handleWhatsAppOrder = () => {
    if (!formData.fullName.trim() || !formData.phone.trim()) {
      const proceed = window.confirm(
        'Tip: Providing your Name and Phone makes WhatsApp processing faster. Continue anyway?'
      );
      if (!proceed) return;
    }

    const itemsList = cartItems
      .map((item, index) => {
        const name = item.product?.name || 'Eco Product';
        const qty = item.quantity;
        const price = item.product?.price || 0;
        return `${index + 1}. ${name} (x${qty}) - ₹${price * qty}`;
      })
      .join('\n');

    const msg = encodeURIComponent(
      `Hello GK Traders! 🌿 I would like to order directly via WhatsApp:\n\n` +
      `📦 Order Items:\n${itemsList}\n\n` +
      `Subtotal: ₹${cartTotal}\n` +
      `Standard Delivery: ₹${deliveryFee}\n` +
      `Total Payable: ₹${totalAmount}\n\n` +
      `🚚 Shipping Details:\n` +
      `• Name: ${formData.fullName || 'To be shared'}\n` +
      `• Phone: ${formData.phone || 'To be shared'}\n` +
      `• Email: ${formData.email || 'To be shared'}\n` +
      `• Address: ${formData.address || 'To be shared'}\n` +
      `• City: ${formData.city || 'To be shared'}\n` +
      `• State: ${formData.state || 'To be shared'}\n` +
      `• Pincode: ${formData.pincode || 'To be shared'}\n\n` +
      `Please send me your UPI QR / GPay link to complete this order!`
    );

    window.open(`https://wa.me/919841202464?text=${msg}`, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream/40 py-24 flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-4 border-forest border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-darkforest text-sm font-medium">Preparing checkout...</p>
      </div>
    );
  }

  if (!cartItems || cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-cream/40 py-16 px-4 flex items-center justify-center relative overflow-hidden">
        {/* Background Watermark */}
        <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
          <Image 
            src="/logo.jpg" 
            alt="GK Traders Watermark" 
            width={600} 
            height={600} 
            className="object-contain mix-blend-multiply" 
          />
        </div>

        <div className="bg-white rounded-3xl p-8 max-w-md text-center shadow-lg border border-sand/40 relative z-10 w-full">
          <div className="w-20 h-20 mx-auto mb-5 rounded-full bg-forest/10 flex items-center justify-center text-forest">
            <FaLeaf size={36} className="text-leaf" />
          </div>
          <h2 className="text-2xl font-heading font-bold text-darkforest mb-3">Your Cart is Empty</h2>
          <p className="text-gray-600 text-sm mb-6 leading-relaxed">
            Please add eco-friendly essentials to your cart before proceeding to checkout.
          </p>
          <Link 
            href="/products" 
            className="inline-flex items-center justify-center gap-2 w-full bg-forest text-cream font-bold py-3.5 px-6 rounded-full hover:bg-darkforest transition-all text-sm shadow-md"
          >
            Browse Eco Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream/30 py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={650} 
          height={650} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header Breadcrumb */}
        <div className="mb-8">
          <Link 
            href="/cart" 
            className="inline-flex items-center gap-2 text-sm text-forest hover:text-darkforest font-semibold mb-3 transition-colors"
          >
            <FaArrowLeft size={12} /> Return to Cart
          </Link>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-leaf mb-1">
            <FaLock size={12} /> Secure Checkout
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest">
            Complete Your Eco-Friendly Order
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Side: Shipping Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-sand/40">
              <div className="flex items-center justify-between pb-4 border-b border-sand/30 mb-6">
                <div>
                  <h2 className="font-heading font-bold text-xl text-darkforest">
                    Shipping & Delivery Address
                  </h2>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Enter your complete delivery address for courier dispatch across India.
                  </p>
                </div>
                <div className="hidden sm:flex items-center gap-1.5 text-xs text-forest bg-leaf/15 font-semibold px-3 py-1 rounded-full">
                  <FaTruck className="text-leaf" /> Flat ₹59 Express
                </div>
              </div>

              <form onSubmit={handleRazorpayPayment} className="space-y-4">
                {/* Full Name */}
                <div>
                  <label htmlFor="fullName" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    placeholder="e.g. Priyadarshini Sundaram"
                    className={`w-full px-4 py-3 rounded-xl border ${
                      formErrors.fullName ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                    } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                    required
                  />
                  {formErrors.fullName && (
                    <p className="text-xs text-red-500 mt-1">{formErrors.fullName}</p>
                  )}
                </div>

                {/* Email and Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="email" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="e.g. priya@example.com"
                      className={`w-full px-4 py-3 rounded-xl border ${
                        formErrors.email ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                      } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                      required
                    />
                    {formErrors.email && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.email}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                      Phone Number (WhatsApp) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="e.g. 9876543210"
                      className={`w-full px-4 py-3 rounded-xl border ${
                        formErrors.phone ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                      } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                      required
                    />
                    {formErrors.phone && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.phone}</p>
                    )}
                  </div>
                </div>

                {/* Street Address */}
                <div>
                  <label htmlFor="address" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                    Street Address & Landmark <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="address"
                    name="address"
                    rows={2}
                    value={formData.address}
                    onChange={handleInputChange}
                    placeholder="House/Flat number, building name, street, nearby landmark"
                    className={`w-full px-4 py-3 rounded-xl border ${
                      formErrors.address ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                    } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all resize-none`}
                    required
                  />
                  {formErrors.address && (
                    <p className="text-xs text-red-500 mt-1">{formErrors.address}</p>
                  )}
                </div>

                {/* City, State, Pincode */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label htmlFor="city" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                      City <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      placeholder="e.g. Chennai"
                      className={`w-full px-4 py-3 rounded-xl border ${
                        formErrors.city ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                      } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                      required
                    />
                    {formErrors.city && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.city}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="state" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                      State <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="state"
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      placeholder="e.g. Tamil Nadu"
                      className={`w-full px-4 py-3 rounded-xl border ${
                        formErrors.state ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                      } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                      required
                    />
                    {formErrors.state && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.state}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="pincode" className="block text-xs font-bold text-darkforest uppercase tracking-wider mb-1.5">
                      PIN Code <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="pincode"
                      name="pincode"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      placeholder="e.g. 600092"
                      maxLength={6}
                      className={`w-full px-4 py-3 rounded-xl border ${
                        formErrors.pincode ? 'border-red-400 bg-red-50/30' : 'border-sand/60 bg-cream/10'
                      } text-darkforest placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-forest text-sm transition-all`}
                      required
                    />
                    {formErrors.pincode && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.pincode}</p>
                    )}
                  </div>
                </div>
              </form>

              {/* Guarantees */}
              <div className="mt-8 pt-6 border-t border-sand/30 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-gray-600">
                <div className="flex items-center gap-2">
                  <FaShieldAlt className="text-leaf text-base flex-shrink-0" />
                  <span>100% Secure Payment processing by Razorpay</span>
                </div>
                <div className="flex items-center gap-2">
                  <FaCheckCircle className="text-leaf text-base flex-shrink-0" />
                  <span>Eco-conscious, zero-plastic packaging guaranteed</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side: Order Summary & Payment Options */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-sm border border-sand/40 sticky top-28 space-y-6">
              <h2 className="font-heading font-bold text-xl text-darkforest border-b border-sand/20 pb-4">
                Order Summary
              </h2>

              {/* Cart Items Review */}
              <div className="max-h-64 overflow-y-auto space-y-3 pr-1 divide-y divide-sand/15">
                {cartItems.map((item) => {
                  const product = item.product || {};
                  const imageUrl = product.image_url || product.image || '/logo.jpg';
                  const itemTotal = (product.price || 0) * item.quantity;

                  return (
                    <div key={item.id} className="pt-3 first:pt-0 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="relative w-14 h-14 rounded-lg overflow-hidden border border-sand/40 bg-cream/20 flex-shrink-0">
                          <Image
                            src={imageUrl}
                            alt={product.name || 'Product'}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium text-darkforest text-sm line-clamp-1">
                            {product.name || 'Eco Product'}
                          </p>
                          <p className="text-xs text-gray-500">
                            Qty: <span className="font-semibold text-darkforest">{item.quantity}</span> × ₹{product.price}
                          </p>
                        </div>
                      </div>
                      <span className="font-bold text-sm text-darkforest whitespace-nowrap">
                        ₹{itemTotal}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 text-sm pt-4 border-t border-sand/20">
                <div className="flex justify-between text-gray-600">
                  <span>Cart Subtotal</span>
                  <span className="font-semibold text-darkforest">₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span className="flex items-center gap-1.5">
                    Standard Express Delivery <FaTruck className="text-leaf text-xs" />
                  </span>
                  <span className="font-semibold text-darkforest">₹{deliveryFee}</span>
                </div>
                <div className="pt-3 border-t border-sand/30 flex justify-between items-baseline">
                  <div>
                    <span className="font-heading font-bold text-lg text-darkforest">Total Payable</span>
                    <p className="text-[11px] text-gray-500">Includes all taxes & delivery</p>
                  </div>
                  <span className="font-heading font-bold text-2xl text-forest">₹{totalAmount}</span>
                </div>
              </div>

              {/* Payment Button */}
              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={handleRazorpayPayment}
                  disabled={isProcessing}
                  className="w-full bg-[#FFA41C] hover:bg-[#FA8900] text-[#0F1111] font-bold py-3.5 px-4 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 transform active:scale-98 text-base cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  <FaCreditCard size={17} />
                  {isProcessing ? 'Connecting to Razorpay...' : `Pay ₹${totalAmount} with Razorpay`}
                </button>
              </div>

              <div className="border-t border-sand/20 pt-4 text-center">
                <p className="text-[11px] text-gray-500 leading-relaxed">
                  GK Traders • Eco-friendly essentials dispatched directly from Chennai, Tamil Nadu. For inquiries: +91 9841202464.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
