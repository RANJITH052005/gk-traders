'use client';

import { useState, use } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { PRODUCTS as STATIC_PRODUCTS } from '@/data/products';
import { 
  FaLeaf, 
  FaMinus, 
  FaPlus, 
  FaChevronRight, 
  FaCheckCircle, 
  FaShoppingCart,
  FaShieldAlt,
  FaTruck,
  FaRecycle,
  FaImages,
  FaBolt,
  FaBoxOpen,
  FaStar,
  FaQuoteLeft,
  FaBookOpen,
  FaArrowRight
} from 'react-icons/fa';

export { STATIC_PRODUCTS };

const PRODUCT_REVIEWS = {
  'eco-friendly-glass-bottle-kids-330ml': [
    {
      name: 'Priya Sundaram',
      location: 'Chennai',
      rating: 5,
      date: '12 days ago',
      title: 'Best decision for my daughter’s school bag!',
      text: 'The glass keeps water completely tasteless and fresh under the hot Chennai sun. The animal silicone sleeve is thick enough to survive multiple accidental drops on classroom floors. Beautiful Blossom Pink shade!'
    },
    {
      name: 'Ravi Teja',
      location: 'Bangalore',
      rating: 5,
      date: '3 weeks ago',
      title: 'Zero plastic smell, super easy to sanitize',
      text: 'Sterilizing in boiling water without worrying about harmful microplastics or warped plastic lids is amazing. My son loves the cute rabbit graphic!'
    }
  ],
  'eco-friendly-bamboo-bottle-750ml': [
    {
      name: 'Vikram Malhotra',
      location: 'Mumbai',
      rating: 5,
      date: '10 days ago',
      title: 'Incredible temperature retention and sleek looks',
      text: 'Hot water stays steaming for a full 12-hour workday. The natural bamboo grain makes it stand out at the office, and the carry loop on the steel cap is super convenient.'
    },
    {
      name: 'Sneha Rao',
      location: 'Coimbatore',
      rating: 5,
      date: '2 weeks ago',
      title: 'Sturdy stainless steel interior',
      text: 'No metallic aftertaste at all. Very easy to clean with a bottle brush. Worth every rupee compared to plastic tumblers.'
    }
  ],
  'eco-friendly-bamboo-toothbrush': [
    {
      name: 'Dr. Ananya Iyer',
      location: 'Coimbatore',
      rating: 5,
      date: '1 month ago',
      title: 'Gentle on gums and fully home compostable',
      text: 'The charcoal bristles do an exceptional job cleaning between teeth without irritating sensitive gums. Buried the old handle in my balcony garden pot — it really decomposes!'
    },
    {
      name: 'Suresh Kumar',
      location: 'Chennai',
      rating: 5,
      date: '3 weeks ago',
      title: 'Smooth finish, no splinters',
      text: 'High quality Moso bamboo with a polished ergonomic grip. Far superior to cheap supermarket bamboo brushes.'
    }
  ],
  'eco-friendly-bamboo-tongue-cleaner': [
    {
      name: 'Meenakshi N.',
      location: 'Madurai',
      rating: 5,
      date: '2 weeks ago',
      title: 'Traditional Ayurvedic morning ritual',
      text: 'The U-shape bend is remarkably flexible and smooth. Zero sharp edges, unlike stainless steel cleaners that sometimes cut. The cotton pouch keeps it hygienic during travel.'
    },
    {
      name: 'Arjun Das',
      location: 'Kochi',
      rating: 5,
      date: '4 weeks ago',
      title: 'Simple, pure and effective',
      text: 'Removes morning toxins in 2 gentle strokes. Highly recommend switching from plastic tongue scrapers.'
    }
  ],
  'eco-friendly-coconut-vessel-scrub': [
    {
      name: 'Lakshmi Narayanan',
      location: 'Chennai',
      rating: 5,
      date: '1 week ago',
      title: 'Tough on burnt dosa pans, gentle on non-stick!',
      text: 'Bought the Box of 5. They clean thoroughly without shedding microplastics into the sink drain. They dry fast and don’t smell sour like yellow foam sponges.'
    },
    {
      name: 'Deepak Nair',
      location: 'Bangalore',
      rating: 5,
      date: '2 weeks ago',
      title: 'Value for money Box of 5',
      text: 'Each pad lasts over a month of daily dishwashing. The reinforced border stitching prevents the coir fibers from unraveling.'
    }
  ],
  'eco-friendly-bamboo-comb': [
    {
      name: 'Shruti Patel',
      location: 'Ahmedabad',
      rating: 5,
      date: '2 weeks ago',
      title: 'Say goodbye to static hair frizz!',
      text: 'Glides smoothly through damp hair without snapping strands. The rounded wooden teeth feel like a calming mini scalp massage each morning.'
    },
    {
      name: 'Kavitha R.',
      location: 'Tiruchirappalli',
      rating: 5,
      date: '3 weeks ago',
      title: 'Naturally conditioned shiny hair',
      text: 'Wooden combs distribute natural oils much better than plastic combs. Compact size fits easily in my handbag.'
    }
  ]
};

export default function ProductDetailPage({ params }) {
  const resolvedParams = params && typeof params.then === 'function' ? use(params) : params;
  const slug = resolvedParams?.slug;
  const product = STATIC_PRODUCTS.find((p) => p.slug === slug || p.id === slug) || STATIC_PRODUCTS[0];

  const router = useRouter();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product.colors ? product.colors[0] : null);
  const [selectedPack, setSelectedPack] = useState('single'); // 'single' or 'box'
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [added, setAdded] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [newReview, setNewReview] = useState({ name: '', rating: 5, comment: '' });

  // Switch color for bottles
  const handleColorChange = (color) => {
    setSelectedColor(color);
    setSelectedImageIndex(0);
  };

  // Switch pack option for Coconut Scrub
  const handlePackChange = (pack) => {
    setSelectedPack(pack);
    setSelectedImageIndex(0);
  };

  // Determine active images list based on color or pack option or product
  const activeImagesList = selectedColor && selectedColor.images
    ? selectedColor.images
    : (product.packImages && product.packImages[selectedPack]
        ? product.packImages[selectedPack]
        : (product.images || [{ url: product.image, label: 'Main View' }]));

  const currentImageObj = activeImagesList[selectedImageIndex] || activeImagesList[0];
  const currentImageUrl = typeof currentImageObj === 'string' ? currentImageObj : currentImageObj.url;
  const currentImageLabel = typeof currentImageObj === 'object' ? currentImageObj.label : null;

  // Pack pricing logic (e.g. Coconut Scrub: Single ₹18, Box of 5 ₹90)
  const isBoxSelected = product.boxPrice && selectedPack === 'box';
  const effectivePrice = isBoxSelected ? product.boxPrice : product.price;
  const effectiveComparePrice = isBoxSelected 
    ? (product.boxPrice === 90 ? 150 : Math.round(product.boxPrice * 1.5))
    : product.compare_at_price;

  const itemTotal = effectivePrice * quantity;
  const deliveryFee = 59;
  const total = itemTotal + deliveryFee;

  const getCartItemPayload = () => {
    let itemName = product.name;
    let itemId = product.id;

    if (selectedColor) {
      itemName = `${product.name} (${selectedColor.name})`;
      itemId = `${product.id}-${selectedColor.name.toLowerCase()}`;
    } else if (isBoxSelected) {
      itemName = `${product.name} (Box of ${product.boxCount || 5})`;
      itemId = `${product.id}-box`;
    }

    return {
      ...product,
      id: itemId,
      name: itemName,
      price: effectivePrice,
      image: currentImageUrl,
    };
  };

  const handleAddToCart = () => {
    addToCart(getCartItemPayload(), quantity, true);
    setAdded(true);
    setTimeout(() => setAdded(false), 2500);
  };

  const handleBuyNow = () => {
    addToCart(getCartItemPayload(), quantity, true);
    router.push('/checkout');
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (newReview.name && newReview.comment) {
      setReviewSubmitted(true);
      setTimeout(() => {
        setShowReviewForm(false);
        setReviewSubmitted(false);
        setNewReview({ name: '', rating: 5, comment: '' });
      }, 2500);
    }
  };

  const reviewsList = PRODUCT_REVIEWS[product.slug] || [
    {
      name: 'Verified Customer',
      location: 'Chennai',
      rating: 5,
      date: 'Recent',
      title: 'Excellent sustainable quality',
      text: 'Very satisfied with the pure eco-friendly craftsmanship. Fast delivery and zero plastic packaging.'
    }
  ];

  return (
    <div className="min-h-screen bg-cream py-8 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Watermark" 
          width={600} 
          height={600} 
          className="object-contain mix-blend-multiply" 
          priority
        />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Breadcrumb */}
        <nav className="flex items-center text-sm text-gray-500 mb-6" aria-label="Breadcrumb">
          <Link href="/" className="hover:text-forest transition-colors">
            Home
          </Link>
          <FaChevronRight className="mx-2 text-xs text-sand" />
          <Link href="/products" className="hover:text-forest transition-colors">
            Products
          </Link>
          <FaChevronRight className="mx-2 text-xs text-sand" />
          <span className="text-darkforest font-semibold truncate max-w-xs">
            {product.name}
          </span>
        </nav>

        {/* Product Card Container */}
        <div className="bg-white rounded-3xl shadow-md overflow-hidden border border-sand/40 flex flex-col md:flex-row mb-12">
          {/* Left Side: Product Image & Thumbnails */}
          <div className="w-full md:w-1/2 flex flex-col border-b md:border-b-0 md:border-r border-sand/30 bg-cream/20">
            <div className="relative aspect-square bg-white">
              {currentImageUrl ? (
                <Image 
                  src={currentImageUrl} 
                  alt={product.name} 
                  fill 
                  className="object-cover transition-all duration-300"
                  priority
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  No Image Available
                </div>
              )}

              {/* 100% Eco-Friendly Badge */}
              <div className="absolute top-4 left-4 bg-forest text-cream text-xs font-semibold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm">
                <FaLeaf className="text-leaf" /> 100% Eco-Friendly
              </div>

              {currentImageLabel && (
                <div className="absolute bottom-4 left-4 bg-darkforest/85 text-cream text-[11px] font-medium px-3 py-1 rounded-full backdrop-blur-xs flex items-center gap-1.5 shadow-sm">
                  <FaImages size={11} className="text-leaf" /> {currentImageLabel}
                </div>
              )}
            </div>

            {/* Thumbnails Row */}
            {activeImagesList && activeImagesList.length > 1 && (
              <div className="p-4 bg-white border-t border-sand/20">
                <span className="text-xs font-bold uppercase tracking-wider text-gray-500 block mb-2.5">
                  Available Views ({activeImagesList.length} Angles):
                </span>
                <div className="flex gap-3 overflow-x-auto pb-1">
                  {activeImagesList.map((imgObj, idx) => {
                    const url = typeof imgObj === 'string' ? imgObj : imgObj.url;
                    const label = typeof imgObj === 'object' ? imgObj.label : `View ${idx + 1}`;
                    return (
                      <button 
                        key={idx}
                        type="button"
                        onClick={() => setSelectedImageIndex(idx)}
                        className={`relative flex-shrink-0 rounded-xl overflow-hidden border-2 transition-all p-0.5 text-left cursor-pointer ${
                          selectedImageIndex === idx 
                            ? 'border-forest ring-2 ring-forest/30 scale-105 shadow-sm' 
                            : 'border-gray-200 hover:border-forest/60 opacity-75 hover:opacity-100'
                        }`}
                        title={label}
                      >
                        <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden">
                          <Image src={url} alt={label} fill className="object-cover" sizes="80px" />
                        </div>
                        <span className="block text-[10px] text-center font-medium mt-1 truncate max-w-[70px] text-gray-700">
                          {label.includes('White') ? 'White BG' : label.includes('Eco') ? 'Eco BG' : label.includes('Authentic') ? 'Real Photo' : label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Right Side: Product Details & Actions */}
          <div className="w-full md:w-1/2 p-6 sm:p-8 md:p-10 flex flex-col justify-between">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between mb-3">
                <div className="inline-block text-xs font-bold uppercase tracking-wider text-leaf bg-leaf/10 px-3 py-1 rounded-full">
                  {product.category || 'Eco Living'}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <div className="flex text-[#FFA41C]">
                    {[...Array(5)].map((_, i) => (
                      <FaStar key={i} size={13} />
                    ))}
                  </div>
                  <span className="font-bold text-darkforest">4.9</span>
                  <span className="text-gray-400">({reviewsList.length + 18} reviews)</span>
                </div>
              </div>

              {/* Product Name */}
              <h1 className="text-3xl font-heading font-bold text-darkforest mb-4 leading-tight">
                {product.name}
              </h1>

              {/* Price Section */}
              <div className="bg-cream/50 rounded-2xl p-4 mb-6 border border-sand/30 flex items-center justify-between">
                <div>
                  <span className="text-xs text-gray-500 uppercase tracking-wider block font-medium">Price</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-forest">₹{effectivePrice}</span>
                    {effectiveComparePrice && (
                      <span className="text-base text-gray-400 line-through">₹{effectiveComparePrice}</span>
                    )}
                    {effectiveComparePrice && (
                      <span className="text-xs text-leaf font-bold">
                        Save ₹{effectiveComparePrice - effectivePrice}
                      </span>
                    )}
                  </div>
                  {product.pricingNote && (
                    <span className="text-xs text-gray-500 mt-1 block">
                      {product.pricingNote}
                    </span>
                  )}
                </div>
                <div className="text-right">
                  <span className="text-xs text-gray-500 uppercase tracking-wider block font-medium">Delivery</span>
                  <span className="text-xs font-bold text-forest bg-white px-2.5 py-1 rounded-full border border-forest/20 inline-block mt-0.5">
                    ₹59 Flat Delivery
                  </span>
                </div>
              </div>

              {/* Pack Selector for Coconut Scrub (Single vs Box of 5) */}
              {product.boxPrice && (
                <div className="mb-6">
                  <label className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-2 flex items-center gap-1.5">
                    <FaBoxOpen className="text-leaf" /> Choose Pack Option:
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => handlePackChange('single')}
                      className={`p-3 rounded-2xl border-2 text-left transition-all cursor-pointer ${
                        selectedPack === 'single'
                          ? 'border-forest bg-forest/5 ring-2 ring-forest/20'
                          : 'border-sand/40 hover:border-forest/50 bg-white'
                      }`}
                    >
                      <span className="block text-xs font-bold text-gray-500 uppercase">Single Piece</span>
                      <div className="flex items-baseline gap-1.5 mt-0.5">
                        <span className="text-lg font-bold text-forest">₹{product.price}</span>
                        <span className="text-xs text-gray-400 line-through">₹{product.compare_at_price}</span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handlePackChange('box')}
                      className={`p-3 rounded-2xl border-2 text-left transition-all relative cursor-pointer ${
                        selectedPack === 'box'
                          ? 'border-forest bg-forest/5 ring-2 ring-forest/20'
                          : 'border-sand/40 hover:border-forest/50 bg-white'
                      }`}
                    >
                      <span className="absolute -top-2.5 right-3 bg-leaf text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                        Save More
                      </span>
                      <span className="block text-xs font-bold text-gray-500 uppercase">Box of {product.boxCount || 5}</span>
                      <div className="flex items-baseline gap-1.5 mt-0.5">
                        <span className="text-lg font-bold text-forest">₹{product.boxPrice}</span>
                        <span className="text-xs text-gray-400 line-through">₹150</span>
                      </div>
                    </button>
                  </div>
                </div>
              )}

              {/* Color Swatches for Kids Bottle */}
              {product.colors && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-heading font-semibold text-darkforest text-sm">
                      Select Color: <span className="text-forest font-bold">{selectedColor?.name}</span>
                    </span>
                    <span className="text-xs text-gray-500">Includes Eco & White BG views</span>
                  </div>
                  <div className="flex gap-3">
                    {product.colors.map((color, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleColorChange(color)}
                        className={`w-11 h-11 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                          selectedColor?.name === color.name 
                            ? 'border-forest scale-110 shadow-md ring-2 ring-forest/30' 
                            : 'border-transparent shadow-sm hover:scale-105'
                        }`}
                        style={{ backgroundColor: color.hex }}
                        aria-label={`Select ${color.name} color`}
                        title={color.name}
                      >
                        {selectedColor?.name === color.name && (
                          <FaCheckCircle className="text-white drop-shadow-md text-sm" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              <p className="text-gray-600 mb-6 leading-relaxed text-base">
                {product.description}
              </p>

              {/* Features List with FaLeaf Icons */}
              {product.features && (
                <div className="mb-6 bg-sand/10 rounded-2xl p-4 border border-sand/30">
                  <h3 className="font-heading font-semibold text-darkforest text-sm mb-3 flex items-center gap-2">
                    <FaLeaf className="text-leaf" /> Product Highlights
                  </h3>
                  <ul className="space-y-2 text-sm">
                    {product.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-gray-700">
                        <FaLeaf className="text-leaf text-xs mt-1 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Related Blog Post Link */}
              {product.relatedBlogSlug && (
                <div className="mb-6 bg-forest/5 p-4 rounded-2xl border border-forest/15 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <FaBookOpen className="text-forest text-lg flex-shrink-0" />
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-forest block">Related Story</span>
                      <span className="text-xs text-darkforest font-semibold">{product.relatedBlogTitle}</span>
                    </div>
                  </div>
                  <Link
                    href={`/blog/${product.relatedBlogSlug}`}
                    className="text-xs font-bold text-forest hover:text-leaf inline-flex items-center gap-1 flex-shrink-0"
                  >
                    <span>Read</span>
                    <FaArrowRight size={10} />
                  </Link>
                </div>
              )}
            </div>

            {/* Quantity & 2 Amazon Action Buttons */}
            <div className="pt-4 border-t border-sand/30">
              {/* Quantity Selector */}
              <div className="flex items-center justify-between gap-4 mb-4">
                <span className="font-medium text-darkforest text-sm">Quantity:</span>
                <div className="flex items-center border border-gray-300 rounded-xl bg-white shadow-xs overflow-hidden">
                  <button 
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2.5 hover:bg-cream text-gray-700 transition-colors cursor-pointer"
                    aria-label="Decrease quantity"
                  >
                    <FaMinus size={11} />
                  </button>
                  <span className="w-12 text-center font-bold text-darkforest text-sm">{quantity}</span>
                  <button 
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2.5 hover:bg-cream text-gray-700 transition-colors cursor-pointer"
                    aria-label="Increase quantity"
                  >
                    <FaPlus size={11} />
                  </button>
                </div>
              </div>

              {/* Amazon Action Buttons: Add to Cart & Buy Now ONLY */}
              <div className="space-y-3">
                {/* 1. Add to Cart Button (Amazon Yellow) */}
                <button 
                  type="button"
                  onClick={handleAddToCart}
                  className={`w-full py-3.5 px-6 rounded-2xl font-bold text-base transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2.5 transform active:scale-98 cursor-pointer ${
                    added
                      ? 'bg-leaf text-white'
                      : 'bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111]'
                  }`}
                >
                  {added ? (
                    <>
                      <FaCheckCircle size={18} />
                      <span>Added to Cart!</span>
                    </>
                  ) : (
                    <>
                      <FaShoppingCart size={18} />
                      <span>Add to Cart</span>
                    </>
                  )}
                </button>

                {/* 2. Buy Now Button (Amazon Orange) */}
                <button 
                  type="button"
                  onClick={handleBuyNow}
                  className="w-full bg-[#FFA41C] hover:bg-[#FA8900] text-[#0F1111] py-3.5 px-6 rounded-2xl font-bold text-base transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2.5 transform active:scale-98 cursor-pointer"
                >
                  <FaBolt size={18} />
                  <span>Buy Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Eco Badges: Biodegradable, Sustainable */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-sand/40 shadow-xs mb-12">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-leaf text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1">
              <FaCheckCircle /> Pure & Eco-Conscious
            </span>
            <h2 className="text-2xl font-heading font-bold text-darkforest">Our Environmental Promise</h2>
            <p className="text-sm text-gray-600 mt-1">100% natural, plastic-free alternatives that protect our planet and your health.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center text-center p-5 rounded-2xl bg-cream/40 border border-sand/20">
              <div className="w-12 h-12 rounded-full bg-leaf/20 text-forest flex items-center justify-center font-bold text-lg mb-3">
                <FaLeaf size={22} className="text-forest" />
              </div>
              <h3 className="font-heading font-semibold text-darkforest text-base mb-1">Biodegradable</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Decomposes naturally in organic soil within months, leaving zero harmful synthetic microplastics behind.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-5 rounded-2xl bg-cream/40 border border-sand/20">
              <div className="w-12 h-12 rounded-full bg-forest/15 text-forest flex items-center justify-center font-bold text-lg mb-3">
                <FaRecycle size={22} className="text-forest" />
              </div>
              <h3 className="font-heading font-semibold text-darkforest text-base mb-1">Sustainable</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Crafted from rapidly renewable Moso bamboo and upcycled South Indian coconut coir fibers.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-5 rounded-2xl bg-cream/40 border border-sand/20">
              <div className="w-12 h-12 rounded-full bg-sand/30 text-forest flex items-center justify-center font-bold text-lg mb-3">
                <FaShieldAlt size={22} className="text-forest" />
              </div>
              <h3 className="font-heading font-semibold text-darkforest text-base mb-1">Chemical-Free</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                100% food-safe with zero BPA, toxic chemical glues, artificial dyes, or bleaches.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-5 rounded-2xl bg-cream/40 border border-sand/20">
              <div className="w-12 h-12 rounded-full bg-leaf/20 text-forest flex items-center justify-center font-bold text-lg mb-3">
                <FaTruck size={22} className="text-forest" />
              </div>
              <h3 className="font-heading font-semibold text-darkforest text-base mb-1">Flat ₹59 Delivery</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Fast courier dispatch straight from our Virugambakkam workshop to your doorstep across India.
              </p>
            </div>
          </div>
        </div>

        {/* Customer Reviews Section */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-sand/40 shadow-xs mb-12">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-8 border-b border-sand/30 gap-6">
            <div>
              <span className="text-leaf text-xs font-bold uppercase tracking-widest block mb-1">
                Verified Feedback
              </span>
              <h2 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest">
                Customer Ratings & Reviews
              </h2>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex text-[#FFA41C]">
                  {[...Array(5)].map((_, i) => (
                    <FaStar key={i} size={18} />
                  ))}
                </div>
                <span className="text-lg font-bold text-darkforest">4.9 out of 5</span>
                <span className="text-sm text-gray-500">Based on verified orders</span>
              </div>
            </div>

            <button
              onClick={() => setShowReviewForm(!showReviewForm)}
              className="px-6 py-3 rounded-full bg-forest text-cream font-bold text-xs sm:text-sm hover:bg-darkforest transition-colors shadow-xs cursor-pointer"
            >
              {showReviewForm ? 'Cancel Review' : 'Write a Review'}
            </button>
          </div>

          {/* Review Submission Form */}
          {showReviewForm && (
            <form onSubmit={handleReviewSubmit} className="my-8 p-6 bg-cream/30 rounded-2xl border border-sand/40 max-w-xl">
              <h3 className="font-heading font-bold text-darkforest mb-4">Share Your Experience</h3>
              {reviewSubmitted ? (
                <div className="p-4 bg-leaf/10 border border-leaf text-forest rounded-xl text-sm font-semibold flex items-center gap-2">
                  <FaCheckCircle className="text-leaf" /> Thank you! Your review has been submitted for moderation.
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      value={newReview.name}
                      onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
                      placeholder="e.g. Anand Kumar"
                      className="w-full p-2.5 rounded-xl border border-sand/50 bg-white text-sm focus:outline-none focus:border-forest"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Rating</label>
                    <select
                      value={newReview.rating}
                      onChange={(e) => setNewReview({ ...newReview, rating: Number(e.target.value) })}
                      className="p-2.5 rounded-xl border border-sand/50 bg-white text-sm focus:outline-none focus:border-forest"
                    >
                      <option value={5}>★★★★★ (5 Stars - Excellent)</option>
                      <option value={4}>★★★★☆ (4 Stars - Very Good)</option>
                      <option value={3}>★★★☆☆ (3 Stars - Average)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Review Details</label>
                    <textarea
                      required
                      rows={3}
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                      placeholder="How was the product quality and packaging?"
                      className="w-full p-2.5 rounded-xl border border-sand/50 bg-white text-sm focus:outline-none focus:border-forest"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-forest text-cream font-bold text-xs rounded-full hover:bg-darkforest transition-colors shadow-xs"
                  >
                    Submit Review
                  </button>
                </div>
              )}
            </form>
          )}

          {/* Reviews List */}
          <div className="divide-y divide-sand/20 mt-6">
            {reviewsList.map((rev, idx) => (
              <div key={idx} className="py-6 first:pt-4 last:pb-0">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-forest text-cream flex items-center justify-center font-bold text-xs">
                      {rev.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-heading font-bold text-darkforest text-sm">{rev.name}</h4>
                      <span className="text-[11px] text-gray-400">{rev.location} • {rev.date}</span>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-leaf bg-leaf/10 px-2.5 py-0.5 rounded-full">
                    <FaCheckCircle size={10} /> Verified Purchase
                  </span>
                </div>

                <div className="flex text-[#FFA41C] gap-1 my-2">
                  {[...Array(rev.rating)].map((_, i) => (
                    <FaStar key={i} size={13} />
                  ))}
                </div>

                {rev.title && (
                  <h5 className="font-semibold text-darkforest text-sm mb-1">{rev.title}</h5>
                )}

                <p className="text-gray-600 text-sm leading-relaxed">
                  {rev.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
