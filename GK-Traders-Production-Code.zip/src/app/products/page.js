'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Image from 'next/image';
import ProductCard from '@/components/ProductCard';
import { FaLeaf, FaTruck, FaSearch, FaTimes, FaSortAmountDown } from 'react-icons/fa';
import { PRODUCTS as STATIC_PRODUCTS } from '@/data/products';

export const CATEGORIES = ['All', 'Bottles', 'Oral Care', 'Kitchen', 'Personal Care'];

function ProductCatalog() {
  const searchParams = useSearchParams();
  const searchParamQuery = searchParams.get('search') || '';

  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState(searchParamQuery);
  const [sortBy, setSortBy] = useState('default'); // 'default', 'price-low', 'price-high'

  useEffect(() => {
    if (searchParamQuery) {
      setSearchQuery(searchParamQuery);
    }
  }, [searchParamQuery]);

  // Filter products by category and search
  const filteredProducts = STATIC_PRODUCTS.filter((product) => {
    const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      product.name.toLowerCase().includes(query) ||
      product.description.toLowerCase().includes(query) ||
      (product.category && product.category.toLowerCase().includes(query));

    return matchesCategory && matchesSearch;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    return 0; // default order
  });

  const clearFilters = () => {
    setActiveCategory('All');
    setSearchQuery('');
    setSortBy('default');
  };

  return (
    <>
      {/* Search Bar & Sort Row */}
      <div className="max-w-3xl mx-auto mb-8 flex flex-col sm:flex-row items-center gap-3">
        {/* Search Input */}
        <div className="relative w-full flex-1">
          <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bottle, toothbrush, scrub, comb..."
            className="w-full pl-11 pr-10 py-3 rounded-full bg-white border border-sand/50 shadow-xs focus:outline-none focus:border-forest text-sm text-darkforest"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-darkforest"
              aria-label="Clear search"
            >
              <FaTimes size={13} />
            </button>
          )}
        </div>

        {/* Sort Select */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <label htmlFor="sortSelect" className="text-xs font-semibold text-gray-500 whitespace-nowrap flex items-center gap-1">
            <FaSortAmountDown size={11} /> Sort by:
          </label>
          <select
            id="sortSelect"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-white border border-sand/50 rounded-full py-2.5 px-4 text-xs font-medium text-darkforest shadow-xs focus:outline-none focus:border-forest"
          >
            <option value="default">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-8">
        {CATEGORIES.map((category) => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-5 py-2 rounded-full font-medium text-sm transition-all duration-200 cursor-pointer ${
              activeCategory === category
                ? 'bg-forest text-cream shadow-md scale-105'
                : 'bg-white text-forest border border-forest/20 hover:bg-lightaccent/40 shadow-xs'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Results status indicator */}
      {(searchQuery || activeCategory !== 'All' || sortBy !== 'default') && (
        <div className="flex items-center justify-between bg-white/70 backdrop-blur-xs px-5 py-2.5 rounded-2xl border border-sand/40 max-w-7xl mx-auto mb-8 text-xs text-gray-600">
          <span>
            Showing <strong>{sortedProducts.length}</strong> {sortedProducts.length === 1 ? 'product' : 'products'}
            {searchQuery && (
              <span>
                {' '}for &quot;<strong>{searchQuery}</strong>&quot;
              </span>
            )}
            {activeCategory !== 'All' && (
              <span>
                {' '}in &quot;<strong>{activeCategory}</strong>&quot;
              </span>
            )}
          </span>
          <button
            onClick={clearFilters}
            className="text-forest hover:text-leaf font-bold underline cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Product Grid / Empty State */}
      {sortedProducts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-sand/30 shadow-xs max-w-md mx-auto">
          <div className="w-12 h-12 rounded-full bg-leaf/20 text-forest flex items-center justify-center mx-auto mb-3">
            <FaLeaf className="text-2xl text-leaf" />
          </div>
          <h3 className="text-lg font-heading font-bold text-darkforest mb-1">
            No matching products found
          </h3>
          <p className="text-sm text-gray-500 mb-5 px-4">
            Try adjusting your search query or selecting a different category.
          </p>
          <button
            onClick={clearFilters}
            className="bg-forest text-cream px-5 py-2.5 rounded-full text-xs font-bold hover:bg-darkforest transition-colors shadow-xs cursor-pointer"
          >
            View All Products
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </>
  );
}

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Watermark" 
          width={600} 
          height={600} 
          className="object-contain mix-blend-multiply" 
          priority
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header with GK Traders Logo Circle */}
        <div className="text-center mb-10 flex flex-col items-center">
          <div className="mb-4 relative w-20 h-20 rounded-full overflow-hidden border-2 border-forest/30 shadow-md bg-white p-1 flex items-center justify-center">
            <Image 
              src="/logo.jpg" 
              alt="GK Traders Logo" 
              width={72} 
              height={72} 
              className="object-contain rounded-full"
              priority
            />
          </div>
          
          <span className="text-leaf text-xs font-bold uppercase tracking-widest flex items-center gap-1.5 mb-2">
            <FaLeaf /> Sustainable Living Essentials
          </span>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-darkforest mb-4">
            Our Eco-Friendly Collection
          </h1>

          <p className="text-gray-600 max-w-2xl mx-auto text-base leading-relaxed">
            Every product is thoughtfully crafted from 100% sustainable, biodegradable materials. Use instant Add to Cart & Buy Now for seamless express delivery across India.
          </p>

          {/* Quick Info Badges */}
          <div className="mt-6 inline-flex flex-wrap items-center justify-center gap-3 sm:gap-6 bg-white/80 backdrop-blur-xs px-6 py-2.5 rounded-full border border-sand/40 shadow-xs text-xs text-gray-700">
            <span className="flex items-center gap-1.5 font-medium text-forest">
              <FaTruck className="text-leaf" /> Flat ₹59 Express Delivery Across India
            </span>
            <span className="hidden sm:inline text-sand">•</span>
            <span className="flex items-center gap-1.5 font-medium text-forest">
              <FaLeaf className="text-leaf" /> 100% Plastic-Free Packaging
            </span>
          </div>
        </div>

        {/* Suspense Wrapper for Catalog Client Search */}
        <Suspense fallback={
          <div className="py-20 text-center text-sm text-gray-500">
            Loading products...
          </div>
        }>
          <ProductCatalog />
        </Suspense>
      </div>
    </div>
  );
}
