'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { 
  FaTrash, 
  FaMinus, 
  FaPlus, 
  FaShoppingCart, 
  FaWhatsapp, 
  FaArrowRight, 
  FaArrowLeft, 
  FaShieldAlt, 
  FaLeaf, 
  FaTruck 
} from 'react-icons/fa';

export default function CartPage() {
  const router = useRouter();
  const cartContext = useCart();
  const authContext = useAuth();

  const cartItems = cartContext?.cartItems || [];
  const updateQuantity = cartContext?.updateQuantity || (() => {});
  const removeItem = cartContext?.removeItem || (() => {});
  const cartTotal = cartContext?.cartTotal ?? cartItems.reduce((acc, item) => acc + ((item.product?.price || 0) * item.quantity), 0);
  const loading = cartContext?.loading || false;
  const user = authContext?.user || null;

  const shippingFee = 59;
  const finalTotal = cartTotal + (cartItems.length > 0 ? shippingFee : 0);

  const handleCheckout = () => {
    router.push('/checkout');
  };

  const handleWhatsAppCartOrder = () => {
    if (cartItems.length === 0) return;

    const itemsList = cartItems
      .map((item, index) => {
        const name = item.product?.name || 'Eco Product';
        const qty = item.quantity;
        const price = item.product?.price || 0;
        const total = price * qty;
        return `${index + 1}. ${name} (x${qty}) - ₹${total}`;
      })
      .join('\n');

    const msg = encodeURIComponent(
      `Hello GK Traders! 🌿 I would like to place an order for the items in my cart:\n\n` +
      `📦 Cart Items:\n${itemsList}\n\n` +
      `Subtotal: ₹${cartTotal}\n` +
      `Delivery Fee: ₹${shippingFee}\n` +
      `Total Payable: ₹${finalTotal}\n\n` +
      (user?.email ? `Customer Email: ${user.email}\n\n` : '') +
      `Please let me know how to complete payment (UPI/GPay) and confirm dispatch. Thank you!`
    );

    window.open(`https://wa.me/919841202464?text=${msg}`, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream/40 py-24 flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-4 border-forest border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-darkforest text-sm font-medium">Loading your eco shopping cart...</p>
      </div>
    );
  }

  // Empty cart state
  if (!cartItems || cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-cream/40 py-16 px-4 relative overflow-hidden flex items-center justify-center">
        {/* Background Watermark */}
        <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
          <Image 
            src="/logo.jpg" 
            alt="GK Traders Watermark" 
            width={600} 
            height={600} 
            className="object-contain mix-blend-multiply" 
          />
        </div>

        <div className="relative z-10 max-w-md w-full bg-white rounded-3xl p-8 sm:p-10 text-center shadow-lg border border-sand/40">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-forest/10 flex items-center justify-center text-forest">
            <FaShoppingCart size={44} className="text-forest/80" />
          </div>
          <span className="text-leaf text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 mb-2">
            <FaLeaf /> GK Traders Cart
          </span>
          <h1 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest mb-3">
            Your Cart is Empty
          </h1>
          <p className="text-gray-600 text-sm leading-relaxed mb-8">
            You haven&apos;t added any eco-friendly essentials to your cart yet. Explore our handcrafted, plastic-free collection today!
          </p>
          <Link
            href="/products"
            className="inline-flex items-center justify-center gap-2 w-full bg-forest text-cream font-bold py-3.5 px-6 rounded-full hover:bg-darkforest transition-all shadow-md transform active:scale-98 text-sm"
          >
            <span>Explore Eco Collection</span>
            <FaArrowRight size={14} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream/30 py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={650} 
          height={650} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Link 
            href="/products" 
            className="inline-flex items-center gap-2 text-sm text-forest hover:text-darkforest font-semibold mb-4 transition-colors"
          >
            <FaArrowLeft size={12} /> Continue Shopping
          </Link>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-leaf mb-1">
                <FaLeaf /> Sustainable Shopping Bag
              </div>
              <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest">
                Shopping Cart ({cartItems.reduce((acc, i) => acc + i.quantity, 0)} {cartItems.reduce((acc, i) => acc + i.quantity, 0) === 1 ? 'item' : 'items'})
              </h1>
            </div>
            {user && (
              <div className="text-xs text-gray-500 bg-white/80 border border-sand/40 px-3 py-1.5 rounded-full">
                Signed in as: <span className="font-semibold text-darkforest">{user.email}</span>
              </div>
            )}
          </div>
        </div>

        {/* Grid Content: Items List + Order Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white rounded-2xl shadow-sm border border-sand/40 divide-y divide-sand/20 overflow-hidden">
              {cartItems.map((item) => {
                const product = item.product || {};
                const imageUrl = product.image_url || product.image || '/logo.jpg';
                const itemTotal = (product.price || 0) * item.quantity;
                const productSlug = product.slug || product.id || '';

                return (
                  <div key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    {/* Item Image & Info */}
                    <div className="flex items-center gap-4 flex-1">
                      <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-sand/40 bg-cream/20 flex-shrink-0">
                        <Image
                          src={imageUrl}
                          alt={product.name || 'Product'}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <Link 
                          href={productSlug ? `/products/${productSlug}` : '/products'}
                          className="font-heading font-semibold text-base sm:text-lg text-darkforest hover:text-forest transition-colors block line-clamp-1"
                        >
                          {product.name || 'Eco-Friendly Product'}
                        </Link>
                        <p className="text-xs text-leaf font-bold mt-0.5">100% Eco-Friendly</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm font-semibold text-darkforest">₹{product.price}</span>
                          {product.compare_at_price && (
                            <span className="text-xs text-gray-400 line-through">₹{product.compare_at_price}</span>
                          )}
                          <span className="text-xs text-gray-400">/ unit</span>
                        </div>
                      </div>
                    </div>

                    {/* Quantity Controls & Line Total & Remove */}
                    <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-3 sm:pt-0 border-t sm:border-t-0 border-sand/20">
                      {/* Quantity Controls */}
                      <div className="flex items-center border border-sand/60 rounded-xl overflow-hidden bg-cream/10">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="w-8 h-8 flex items-center justify-center text-darkforest hover:bg-sand/30 transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <FaMinus size={11} />
                        </button>
                        <span className="w-10 text-center font-bold text-sm text-darkforest">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center text-darkforest hover:bg-sand/30 transition-colors"
                          aria-label="Increase quantity"
                        >
                          <FaPlus size={11} />
                        </button>
                      </div>

                      {/* Line Total */}
                      <div className="text-right min-w-[70px]">
                        <span className="block text-xs text-gray-500">Total</span>
                        <span className="text-base font-bold text-darkforest">₹{itemTotal}</span>
                      </div>

                      {/* Remove Button */}
                      <button
                        type="button"
                        onClick={() => removeItem(item.id)}
                        className="text-gray-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50 transition-colors"
                        title="Remove item"
                        aria-label="Remove item"
                      >
                        <FaTrash size={16} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Eco perks banner */}
            <div className="bg-white/80 rounded-2xl p-4 border border-sand/40 flex flex-wrap items-center justify-between gap-4 text-xs text-gray-600">
              <span className="flex items-center gap-2 font-medium text-forest">
                <FaLeaf className="text-leaf" /> Plastic-free compostable packaging
              </span>
              <span className="flex items-center gap-2 font-medium text-forest">
                <FaTruck className="text-leaf" /> Flat ₹59 express delivery across India
              </span>
              <span className="flex items-center gap-2 font-medium text-forest">
                <FaShieldAlt className="text-leaf" /> 100% Quality guarantee
              </span>
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-sm border border-sand/40 sticky top-28 space-y-6">
              <h2 className="font-heading font-bold text-xl text-darkforest border-b border-sand/20 pb-4">
                Order Summary
              </h2>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span className="font-semibold text-darkforest">₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span className="flex items-center gap-1.5">
                    Standard Delivery <FaTruck className="text-leaf text-xs" />
                  </span>
                  <span className="font-semibold text-darkforest">₹{shippingFee}</span>
                </div>
                <div className="pt-3 border-t border-sand/30 flex justify-between items-baseline">
                  <div>
                    <span className="font-heading font-bold text-lg text-darkforest">Total</span>
                    <p className="text-[11px] text-gray-500">Including all applicable taxes</p>
                  </div>
                  <span className="font-heading font-bold text-2xl text-forest">₹{finalTotal}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={handleCheckout}
                  className="w-full bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] py-3.5 px-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md transform active:scale-98 text-sm cursor-pointer"
                >
                  Proceed to Checkout <FaArrowRight size={14} />
                </button>
              </div>

              <div className="border-t border-sand/20 pt-4 text-center">
                <p className="text-[11px] text-gray-500 leading-relaxed">
                  🔒 Secure checkout with Razorpay or direct WhatsApp ordering. We dispatch all eco-friendly orders within 24-48 hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
