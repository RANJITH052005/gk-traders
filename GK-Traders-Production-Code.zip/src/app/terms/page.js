import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';

export const metadata = {
  title: 'Terms & Conditions | GK Traders',
  description: 'Terms and conditions for GK Traders.',
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 p-8 sm:p-12">
          <div className="flex items-center gap-2 text-forest font-semibold mb-3">
            <FaLeaf className="text-leaf" /> Legal Agreements
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-6">
            Terms & Conditions
          </h1>
          <p className="text-sm text-gray-500 mb-8">Last updated: October 2026</p>

          <div className="space-y-6 text-gray-700 leading-relaxed text-sm sm:text-base">
            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">1. Overview</h2>
              <p>
                This website is operated by <strong>GK Traders</strong>. By visiting our site or purchasing our eco-friendly products, you engage in our service and agree to be bound by the following terms and conditions.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">2. Products & Pricing</h2>
              <p>
                All product descriptions and pricing are subject to change without notice. We make every effort to display the colors and images of our products accurately. Prices shown are inclusive of applicable taxes.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">3. Payments & Gateway</h2>
              <p>
                We accept online payments via <strong>Razorpay</strong>, supporting UPI, Debit/Credit Cards, and Net Banking. All financial transactions are encrypted and processed through certified PCI-DSS compliant secure servers.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">4. User Account & Conduct</h2>
              <p>
                You agree to provide true, accurate, and complete information when creating an account or placing an order on our platform. You are responsible for maintaining the confidentiality of your account credentials.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">5. Governing Law</h2>
              <p>
                These terms shall be governed by and construed in accordance with the laws of India, under the jurisdiction of courts in Chennai, Tamil Nadu.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">6. Contact Information</h2>
              <p>
                Questions regarding Terms & Conditions should be directed to:
              </p>
              <ul className="list-none pl-0 mt-2 space-y-1 text-sm">
                <li><strong>GK Traders</strong></li>
                <li>Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092</li>
                <li>Email: hellogktraders@gmail.com</li>
                <li>Phone: +91 9841202464</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

