import Link from 'next/link';
import Image from 'next/image';
import HeroBanner from '@/components/HeroBanner';
import EcoQuotes from '@/components/EcoQuotes';
import ProductCard from '@/components/ProductCard';
import Testimonials from '@/components/Testimonials';
import FAQ from '@/components/FAQ';
import WholesaleBanner from '@/components/WholesaleBanner';
import { FaRecycle, FaBan, FaLeaf, FaTruck, FaShieldAlt, FaAward } from 'react-icons/fa';
import { PRODUCTS as STATIC_PRODUCTS } from '@/data/products';

const BLOG_PREVIEWS = [
  {
    slug: 'why-switch-to-bamboo-toothbrushes',
    title: 'Why Switching to a Bamboo Toothbrush Matters More Than You Think',
    excerpt: 'Over 4.7 billion plastic toothbrushes are dumped into oceans and landfills each year. Here is how one simple switch protects marine life.',
    image: '/images/bamboo-toothbrush-eco.jpg',
    category: 'Sustainable Living',
  },
  {
    slug: 'ancient-science-of-bamboo-tongue-cleaners',
    title: 'The Ancient Ayurvedic Science of Bamboo Tongue Scraping',
    excerpt: 'Brushing alone leaves 80% of mouth bacteria behind. Discover why bamboo tongue scrapers are gentle on taste buds and zero-waste.',
    image: '/images/bamboo-tongue-cleaner-eco.jpg',
    category: 'Oral Health & Ayurveda',
  },
  {
    slug: 'say-goodbye-to-plastic-bottles-for-kids',
    title: 'Safe Hydration: Why Glass Beats Plastic Bottles for Children',
    excerpt: 'Microplastics and BPA chemicals in hot plastic bottles can harm growing children. Here is why borosilicate glass is the pure choice.',
    image: '/images/glass-bottle-kids-pink-eco.jpg',
    category: 'Kids & Family',
  },
];

export default function Home() {
  return (
    <div className="bg-[#FDFBF7]">
      {/* 1. HeroBanner Component */}
      <HeroBanner />

      {/* Trust Highlights Strip */}
      <div className="bg-forest text-cream py-4 border-y border-leaf/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm">
              <FaLeaf className="text-leaf flex-shrink-0" />
              <span>100% Plastic-Free</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm">
              <FaTruck className="text-leaf flex-shrink-0" />
              <span>Flat ₹59 Delivery India-Wide</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm">
              <FaShieldAlt className="text-leaf flex-shrink-0" />
              <span>Zero Toxic Chemicals / BPA</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm">
              <FaAward className="text-leaf flex-shrink-0" />
              <span>Handcrafted in Chennai</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Why Choose Eco-Friendly? Section */}
      <section className="py-16 bg-cream/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-4">
              Why Choose Eco-Friendly?
            </h2>
            <p className="text-gray-600 text-base sm:text-lg">
              Every small shift towards natural, earth-first products helps eliminate single-use plastic waste and protects our planet for future generations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Sustainable Card */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border-2 border-leaf flex flex-col items-center text-center hover:shadow-md transition-all hover:-translate-y-1">
              <div className="w-16 h-16 rounded-full bg-leaf/10 flex items-center justify-center text-leaf text-3xl mb-6">
                <FaLeaf />
              </div>
              <h3 className="text-xl font-heading font-bold text-darkforest mb-3">
                Sustainable
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Responsibly harvested from fast-growing, renewable resources like bamboo and coconut husks, supporting balanced and thriving ecosystems.
              </p>
            </div>

            {/* Plastic-Free Card */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border-2 border-sand flex flex-col items-center text-center hover:shadow-md transition-all hover:-translate-y-1">
              <div className="w-16 h-16 rounded-full bg-sand/20 flex items-center justify-center text-sand text-3xl mb-6">
                <FaBan />
              </div>
              <h3 className="text-xl font-heading font-bold text-darkforest mb-3">
                Plastic-Free
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Zero synthetic plastics, BPA, or harsh toxins. Keep your everyday lifestyle pure and keep persistent microplastics out of our oceans and food chain.
              </p>
            </div>

            {/* Biodegradable Card */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border-2 border-forest flex flex-col items-center text-center hover:shadow-md transition-all hover:-translate-y-1">
              <div className="w-16 h-16 rounded-full bg-forest/10 flex items-center justify-center text-forest text-3xl mb-6">
                <FaRecycle />
              </div>
              <h3 className="text-xl font-heading font-bold text-darkforest mb-3">
                Biodegradable
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                100% compostable and natural materials that return safely to the earth without contaminating soil or lingering for centuries in landfills.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Our Products Section */}
      <section className="py-16 bg-white/40 backdrop-blur-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-leaf text-xs font-bold uppercase tracking-widest block mb-2">
              Bestselling Zero-Waste Essentials
            </span>
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-4">
              Our Eco-Friendly Products
            </h2>
            <p className="text-gray-600 text-base sm:text-lg">
              Explore our handcrafted collection of zero-plastic daily essentials, thoughtfully designed for natural, mindful living.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {STATIC_PRODUCTS.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 bg-forest hover:bg-darkforest text-cream font-bold px-8 py-3.5 rounded-full text-base transition-all shadow-md hover:scale-105"
            >
              <span>View Full Products Catalog</span>
              <span>&rarr;</span>
            </Link>
          </div>
        </div>
      </section>

      {/* 4. Customer Testimonials Section */}
      <Testimonials />

      {/* 5. Corporate Wholesale Banner */}
      <WholesaleBanner />

      {/* 6. From Our Company Blog Section */}
      <section className="py-16 bg-cream/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-2">
                From Our Company Blog
              </h2>
              <p className="text-gray-600 text-base">
                Insights, guides, and practical tips on living plastic-free and embracing sustainable habits.
              </p>
            </div>
            <Link 
              href="/blog" 
              className="mt-4 md:mt-0 inline-flex items-center gap-2 text-forest hover:text-leaf font-bold transition-colors text-base"
            >
              <span>Explore All Articles</span>
              <span>&rarr;</span>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_PREVIEWS.map((post) => (
              <article 
                key={post.slug}
                className="bg-white rounded-2xl shadow-sm border border-sand/40 overflow-hidden flex flex-col hover:shadow-md transition-shadow group"
              >
                <Link href={`/blog/${post.slug}`} className="block relative aspect-[16/10] bg-cream overflow-hidden">
                  <Image 
                    src={post.image} 
                    alt={post.title} 
                    fill 
                    className="object-cover group-hover:scale-105 transition-transform duration-500" 
                    sizes="(max-width: 768px) 100vw, 33vw"
                  />
                </Link>
                <div className="p-6 flex flex-col flex-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-leaf mb-2">
                    {post.category}
                  </span>
                  <h3 className="font-heading font-bold text-lg text-darkforest mb-3 group-hover:text-forest transition-colors line-clamp-2">
                    <Link href={`/blog/${post.slug}`}>
                      {post.title}
                    </Link>
                  </h3>
                  <p className="text-sm text-gray-600 mb-6 flex-1 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <Link 
                    href={`/blog/${post.slug}`}
                    className="text-xs font-bold text-forest hover:text-leaf inline-flex items-center gap-1.5 mt-auto"
                  >
                    <span>Read Article</span>
                    <span>&rarr;</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Rotating Eco Quotes */}
      <EcoQuotes />

      {/* 8. Frequently Asked Questions */}
      <FAQ />

      {/* 9. Pure Eco Living CTA Section */}
      <section className="py-16 bg-forest text-cream">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-16 h-16 bg-leaf text-darkforest rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <FaLeaf size={30} />
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold mb-4">
            Pure Eco Living, Delivered Straight to Your Door
          </h2>
          <p className="text-cream/90 text-base sm:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            Experience seamless online shopping, instant Add to Cart and Buy Now options, secure payment processing, and flat ₹59 doorstep delivery across India. Switch to 100% plastic-free daily essentials today.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] font-bold px-8 py-4 rounded-full text-base sm:text-lg shadow-xl hover:scale-105 transition-all"
            >
              <span>Shop All Products</span>
              <span>&rarr;</span>
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-transparent hover:bg-white/10 text-cream font-bold px-8 py-4 rounded-full text-base sm:text-lg border-2 border-cream/50 transition-all"
            >
              <span>Contact Virugambakkam Office</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
