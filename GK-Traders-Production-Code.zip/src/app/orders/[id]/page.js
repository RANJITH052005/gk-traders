'use client';
import { use } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { FaCheckCircle, FaWhatsapp, FaLeaf, FaArrowRight } from 'react-icons/fa';

export default function OrderDetail({ params }) {
  const { id } = use(params);
  const searchParams = useSearchParams();
  const isSuccess = searchParams.get('success');

  const orderMsg = encodeURIComponent(`Hi GK Traders! I just placed Order #${id}. Could you please confirm dispatch details?`);

  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-2xl mx-auto relative z-10">
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 p-8 sm:p-12 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 text-green-600">
            <FaCheckCircle className="text-4xl" />
          </div>

          <span className="inline-flex items-center gap-1.5 bg-leaf/20 text-forest text-xs font-bold px-3 py-1 rounded-full mb-4">
            <FaLeaf /> Eco-Friendly Order Confirmed
          </span>

          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-3">
            Thank You for Choosing Sustainable!
          </h1>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            Your payment was successful and your order is being prepared for dispatch.
          </p>

          <div className="bg-cream/60 rounded-2xl p-6 text-left mb-8 border border-sand/30">
            <div className="flex justify-between items-center mb-4 pb-4 border-b border-sand/20">
              <span className="text-sm text-gray-500 font-medium">Order Reference:</span>
              <span className="font-mono font-bold text-darkforest text-sm">{id}</span>
            </div>
            <div className="flex justify-between items-center mb-4 pb-4 border-b border-sand/20">
              <span className="text-sm text-gray-500 font-medium">Payment Status:</span>
              <span className="inline-flex items-center gap-1 text-green-700 bg-green-100 px-2.5 py-0.5 rounded-full text-xs font-semibold">
                ✓ Paid via Razorpay
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500 font-medium">Estimated Delivery:</span>
              <span className="text-sm font-semibold text-forest">3 – 5 Business Days</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={`https://wa.me/919841202464?text=${orderMsg}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-6 py-3.5 rounded-xl font-bold hover:bg-[#20bd5a] transition-colors shadow-md"
            >
              <FaWhatsapp className="text-xl" /> Track on WhatsApp
            </a>
            <Link
              href="/products"
              className="inline-flex items-center justify-center gap-2 bg-forest text-cream px-6 py-3.5 rounded-xl font-bold hover:bg-darkforest transition-colors shadow-md"
            >
              Continue Shopping <FaArrowRight className="text-sm" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
