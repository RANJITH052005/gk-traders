'use client';

import Link from 'next/link';
import Image from 'next/image';
import { FaShoppingBag, FaLeaf, FaArrowRight } from 'react-icons/fa';

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-cream py-16 px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={600} 
          height={600} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-sm border border-sand/40 p-8 sm:p-10 text-center relative z-10">
        {/* Brand Logo */}
        <div className="flex justify-center mb-6">
          <Link
            href="/"
            className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-forest/30 shadow-sm bg-white p-1 block hover:border-forest transition-colors"
          >
            <Image
              src="/logo.jpg"
              alt="GK Traders Logo"
              fill
              className="object-contain"
              priority
            />
          </Link>
        </div>

        <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-leaf mb-2 bg-leaf/10 px-3 py-1 rounded-full">
          <FaLeaf size={11} /> Customer Account
        </div>

        {/* Heading */}
        <h1 className="text-3xl font-heading font-bold text-darkforest mb-3">
          My Orders
        </h1>

        {/* Empty state icon */}
        <div className="w-20 h-20 rounded-full bg-cream text-forest mx-auto flex items-center justify-center my-6 border border-sand/40">
          <FaShoppingBag size={32} className="text-forest" />
        </div>

        {/* Message */}
        <p className="text-gray-600 mb-8 text-sm sm:text-base leading-relaxed">
          You haven&apos;t placed any eco-friendly orders yet. Discover our sustainable collection and enjoy flat ₹59 delivery across India!
        </p>

        {/* Amazon Yellow Button to /products */}
        <Link
          href="/products"
          className="inline-flex items-center justify-center gap-2.5 w-full py-3.5 px-6 rounded-2xl bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] font-bold text-sm sm:text-base transition-all shadow-sm hover:shadow-md hover:scale-[1.02] transform"
        >
          <span>Start Shopping</span>
          <FaArrowRight size={13} />
        </Link>
      </div>
    </div>
  );
}
