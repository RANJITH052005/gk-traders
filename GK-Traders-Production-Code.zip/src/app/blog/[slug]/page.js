import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { FaLeaf, FaClock, FaWhatsapp, FaArrowLeft, FaShareAlt } from 'react-icons/fa';
import { BLOG_POSTS } from '../page';

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const post = BLOG_POSTS.find((p) => p.id === slug);
  if (!post) return { title: 'Post Not Found | GK Traders' };
  return {
    title: `${post.title} | GK Traders Blog`,
    description: post.excerpt,
  };
}

export default async function BlogPostPage({ params }) {
  const { slug } = await params;
  const post = BLOG_POSTS.find((p) => p.id === slug);

  if (!post) {
    notFound();
  }

  const orderMsg = encodeURIComponent(`Hi GK Traders! I read your article "${post.title}" and would like to order the ${post.relatedProduct?.name || 'eco-friendly product'}. Can you share details and payment options?`);

  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Back Link */}
        <Link 
          href="/blog" 
          className="inline-flex items-center gap-2 text-forest hover:text-leaf font-medium text-sm mb-8 transition-colors"
        >
          <FaArrowLeft size={12} /> Back to All Articles
        </Link>

        <article className="bg-white rounded-3xl shadow-sm border border-sand/30 overflow-hidden p-6 sm:p-12 mb-12">
          {/* Category & Meta */}
          <div className="flex flex-wrap items-center gap-3 text-xs font-semibold text-leaf mb-4 uppercase tracking-wider">
            <span className="bg-leaf/10 px-3 py-1 rounded-full">{post.category}</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-gray-500"><FaClock /> {post.readTime}</span>
            <span>•</span>
            <span className="text-gray-500">{post.date}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-darkforest mb-6 leading-tight">
            {post.title}
          </h1>

          <div className="flex items-center gap-3 pb-8 mb-8 border-b border-sand/20 text-sm text-gray-600">
            <div className="w-9 h-9 rounded-full bg-forest text-cream flex items-center justify-center font-bold text-xs">
              GK
            </div>
            <div>
              <p className="font-semibold text-darkforest">{post.author}</p>
              <p className="text-xs text-gray-400">Virugambakkam, Chennai</p>
            </div>
          </div>

          {/* Hero Article Image */}
          <div className="relative aspect-[16/9] rounded-2xl overflow-hidden mb-10 bg-sand/20">
            <Image 
              src={post.image} 
              alt={post.title} 
              fill 
              className="object-cover"
              priority
            />
          </div>

          {/* Post Content */}
          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-6">
            {post.content.split('\n\n').map((paragraph, index) => {
              if (paragraph.startsWith('### ')) {
                return (
                  <h3 key={index} className="text-2xl font-heading font-bold text-darkforest pt-4 pb-2">
                    {paragraph.replace('### ', '')}
                  </h3>
                );
              }
              if (paragraph.startsWith('- ') || paragraph.startsWith('1. ')) {
                const items = paragraph.split('\n');
                return (
                  <ul key={index} className="list-disc pl-6 space-y-2 text-gray-700">
                    {items.map((item, idx) => (
                      <li key={idx} dangerouslySetInnerHTML={{ __html: item.replace(/^[-1234567890.]+\s*/, '').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                    ))}
                  </ul>
                );
              }
              return (
                <p key={index} className="text-base sm:text-lg text-gray-700 leading-relaxed">
                  {paragraph}
                </p>
              );
            })}
          </div>

          {/* Related Product Card within Post */}
          {post.relatedProduct && (
            <div className="mt-12 bg-cream/70 rounded-2xl p-6 sm:p-8 border-2 border-dashed border-leaf/40 flex flex-col sm:flex-row items-center gap-6">
              <div className="relative w-28 h-28 flex-shrink-0 rounded-xl overflow-hidden bg-white shadow-sm">
                <Image 
                  src={post.relatedProduct.image} 
                  alt={post.relatedProduct.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <span className="text-xs font-bold text-leaf uppercase tracking-wider">Featured Eco Product</span>
                <h4 className="font-heading font-bold text-xl text-darkforest mt-1">
                  {post.relatedProduct.name}
                </h4>
                <p className="text-forest font-bold text-lg mt-1">{post.relatedProduct.price}</p>
              </div>
              <div className="flex flex-col gap-2 w-full sm:w-auto">
                <Link
                  href={post.relatedProduct.link}
                  className="inline-flex items-center justify-center gap-2 bg-[#FFD814] hover:bg-[#F7CA00] text-[#0F1111] px-6 py-3.5 rounded-xl font-bold transition-all shadow-sm hover:shadow-md text-sm whitespace-nowrap"
                >
                  View Product & Buy Now →
                </Link>
              </div>
            </div>
          )}
        </article>
      </div>
    </div>
  );
}
