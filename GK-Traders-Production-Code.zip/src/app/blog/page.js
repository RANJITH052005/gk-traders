import Link from 'next/link';
import Image from 'next/image';
import { FaLeaf, FaClock, FaArrowRight, FaWhatsapp, FaTags } from 'react-icons/fa';

export const metadata = {
  title: 'Blog & Eco Insights | GK Traders',
  description: 'Learn about zero-waste living, bamboo benefits, and sustainable daily habits from the GK Traders blog.',
};

export const BLOG_POSTS = [
  {
    id: 'why-switch-to-bamboo-toothbrushes',
    title: 'Why Switching to a Bamboo Toothbrush Matters More Than You Think',
    excerpt: 'Over 4.7 billion plastic toothbrushes are dumped into oceans and landfills each year. Here is how one simple switch protects marine life.',
    category: 'Sustainable Living',
    readTime: '3 min read',
    date: 'Oct 18, 2026',
    author: 'GK Traders Editorial',
    image: '/images/bamboo-toothbrush-eco.jpg',
    content: `Did you know that every plastic toothbrush you have ever used in your lifetime still exists somewhere on this planet? Plastic handles take more than 400 years to decompose, often breaking down into harmful microplastics that poison marine animals.

### The Natural Alternative: Moso Bamboo
At GK Traders, our toothbrushes are crafted from 100% biodegradable Moso bamboo. Moso bamboo is a wonder plant:
- **Fast Growing:** Bamboo can grow up to 3 feet in a single 24-hour period without synthetic fertilizers or pesticides.
- **Naturally Antibacterial:** It resists mold, fungus, and bacteria naturally, keeping your oral hygiene cleaner.
- **Home Compostable:** Once the charcoal bristles are pulled out, the handle composts in soil within 4-6 months.

### How to Care for Your Bamboo Toothbrush
1. Keep it in a dry, ventilated holder (avoid standing water).
2. Replace it every 3 months, just like any dentist recommends.
3. When finished, bury the handle in your garden pot to enrich your soil!`,
    relatedProduct: {
      name: 'Eco-Friendly Bamboo Toothbrush',
      price: '₹99',
      image: '/images/bamboo-toothbrush-eco.jpg',
      link: '/products/eco-friendly-bamboo-toothbrush'
    }
  },
  {
    id: 'ancient-science-of-bamboo-tongue-cleaners',
    title: 'The Ancient Ayurvedic Science of Bamboo Tongue Scraping',
    excerpt: 'Brushing alone leaves 80% of mouth bacteria behind. Discover why bamboo tongue scrapers are gentle on taste buds and zero-waste.',
    category: 'Oral Health & Ayurveda',
    readTime: '4 min read',
    date: 'Oct 14, 2026',
    author: 'GK Traders Wellness',
    image: '/images/bamboo-tongue-cleaner-eco.jpg',
    content: `Ayurveda has recommended daily tongue cleaning (Jihwa Prakshalana) for thousands of years. While metal scrapers can sometimes cause harsh cuts and plastic cleaners add to global pollution, smooth handcrafted bamboo is the ideal middle ground.

### Why Clean Your Tongue with Bamboo?
- **Removes "Ama" (Toxins):** Overnight, your digestive system expels toxins onto the surface of your tongue. Scraping in the morning prevents re-ingestion.
- **Enhances Taste Senses:** Removing the white film frees your taste buds, helping you appreciate fresh flavors and naturally digest food better.
- **Zero Cuts or Bleeding:** Bamboo is supple and rounded with ergonomic U-shaped flexibility, so it contours comfortably without scraping too harshly.

### Our Handcrafted GK Traders Scraper
Made from single strips of seasoned bamboo, our U-shaped scraper requires zero plastic packaging and comes in a pure cotton reusable pouch.`,
    relatedProduct: {
      name: 'Eco-Friendly Bamboo Tongue Cleaner',
      price: '₹79',
      image: '/images/bamboo-tongue-cleaner-eco.jpg',
      link: '/products/eco-friendly-bamboo-tongue-cleaner'
    }
  },
  {
    id: 'say-goodbye-to-plastic-bottles-for-kids',
    title: 'Safe Hydration: Why Glass & Bamboo Beat Plastic Bottles for Kids',
    excerpt: 'Microplastics and BPA chemicals in hot plastic bottles can harm growing children. Here is why borosilicate glass is the pure choice.',
    category: 'Family & Health',
    readTime: '5 min read',
    date: 'Oct 10, 2026',
    author: 'GK Traders Care',
    image: '/images/glass-bottle-kids-pink-eco.jpg',
    content: `When parents pack school water bottles in warm climates like Chennai, plastic bottles often release chemicals like BPA, BPS, and phthalates directly into the drinking water. 

### Why Pure Borosilicate Glass is Unbeatable
1. **Chemical-Free Purity:** Glass never leaches flavors, odors, or endocrine-disrupting chemicals, regardless of water temperature.
2. **Cute & Drop-Safe:** Our GK Traders 330ml Kids Glass Bottles feature a soft, protective silicone sleeve with adorable rabbit artwork and carrying loops.
3. **Easy Sanitization:** Unlike plastic that gets scratches where bacteria hide, glass can be sterilized with boiling water without warping.

Available in child-friendly colors: Pastel Pink, Meadow Green, and Warm Earth Brown.`,
    relatedProduct: {
      name: 'Eco-Friendly Glass Bottle (330ml) Kids',
      price: '₹199',
      image: '/images/glass-bottle-kids-pink-eco.jpg',
      link: '/products/eco-friendly-glass-bottle-kids-330ml'
    }
  },
  {
    id: 'coconut-coir-the-natural-kitchen-powerhouse',
    title: 'Coconut Coir: How Kerala & Tamil Nadu Tradition Solved Kitchen Grease',
    excerpt: 'Ditch the green synthetic scrub sponges that shed microplastics into your drains. Natural coconut coir scrubs cleaner and lasts longer.',
    category: 'Zero-Waste Kitchen',
    readTime: '3 min read',
    date: 'Oct 05, 2026',
    author: 'GK Traders Kitchen',
    image: '/images/coconut-scrub-single-eco-v2.jpg',
    content: `Synthetic yellow and green kitchen sponges are made of polyurethane plastic and microfibers. Every time you wash dishes, microplastic fibers flow down your sink into local rivers and oceans.

### Meet the Coconut Coir Scrub
Coconut coir is the tough, fibrous husk of coconuts grown right across South India:
- **Tough on Stains, Soft on Non-Stick:** The natural fibers cut through burnt grease effortlessly without scratching your expensive teflon or ceramic cookware.
- **Naturally Odor-Free:** Coconut fibers dry rapidly and resist bacterial odor build-up, lasting 3 to 4 times longer than supermarket sponges.
- **Completely Backyard Compostable:** Throw it in your flower pot or compost bin when retired!`,
    relatedProduct: {
      name: 'Eco-Friendly Coconut Vessel Scrub',
      price: '₹18',
      image: '/images/coconut-scrub-single-eco-v2.jpg',
      link: '/products/eco-friendly-coconut-vessel-scrub'
    }
  }
];

export default function BlogIndexPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-leaf/20 text-forest text-sm font-bold px-4 py-1.5 rounded-full mb-4">
            <FaLeaf /> GK Traders Sustainable Journal
          </div>
          <h1 className="text-4xl sm:text-5xl font-heading font-bold text-darkforest mb-4">
            Stories & Guides for a Greener Tomorrow
          </h1>
          <p className="text-gray-600 text-lg">
            Practical insights on eco-friendly living, zero-waste Indian homes, and natural alternatives to everyday plastics.
          </p>
        </div>

        {/* Featured Post (First one) */}
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 overflow-hidden mb-12 flex flex-col lg:flex-row hover:shadow-md transition-shadow">
          <div className="lg:w-1/2 relative min-h-[300px] lg:min-h-full bg-sand/20">
            <Image 
              src={BLOG_POSTS[0].image} 
              alt={BLOG_POSTS[0].title}
              fill
              className="object-cover"
            />
          </div>
          <div className="lg:w-1/2 p-8 sm:p-12 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-xs font-semibold text-leaf mb-3 uppercase tracking-wider">
                <span>{BLOG_POSTS[0].category}</span>
                <span>•</span>
                <span className="flex items-center gap-1"><FaClock /> {BLOG_POSTS[0].readTime}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest mb-4 leading-snug">
                <Link href={`/blog/${BLOG_POSTS[0].id}`} className="hover:text-forest transition-colors">
                  {BLOG_POSTS[0].title}
                </Link>
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {BLOG_POSTS[0].excerpt}
              </p>
            </div>

            <div className="flex items-center justify-between pt-6 border-t border-sand/20">
              <span className="text-xs text-gray-500">{BLOG_POSTS[0].date}</span>
              <Link 
                href={`/blog/${BLOG_POSTS[0].id}`}
                className="inline-flex items-center gap-2 text-forest font-bold hover:text-leaf transition-colors text-sm"
              >
                Read Article <FaArrowRight />
              </Link>
            </div>
          </div>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BLOG_POSTS.slice(1).map((post) => (
            <article 
              key={post.id}
              className="bg-white rounded-2xl shadow-sm border border-sand/30 overflow-hidden flex flex-col hover:shadow-md transition-shadow"
            >
              <div className="relative aspect-[16/10] bg-sand/20 overflow-hidden">
                <Image 
                  src={post.image} 
                  alt={post.title}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-leaf mb-2">
                  <FaTags /> {post.category}
                </div>
                <h3 className="font-heading font-bold text-xl text-darkforest mb-3 line-clamp-2">
                  <Link href={`/blog/${post.id}`} className="hover:text-forest transition-colors">
                    {post.title}
                  </Link>
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3 leading-relaxed flex-1">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-sand/20 text-xs">
                  <span className="text-gray-500">{post.date}</span>
                  <Link 
                    href={`/blog/${post.id}`}
                    className="font-bold text-forest hover:text-leaf flex items-center gap-1"
                  >
                    Read More <FaArrowRight size={10} />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* WhatsApp Consultation Banner */}
        <div className="mt-16 bg-forest text-cream rounded-3xl p-8 sm:p-12 text-center max-w-4xl mx-auto shadow-lg relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="text-2xl sm:text-3xl font-heading font-bold mb-3">
              Have Questions or Want to Switch to Eco-Friendly?
            </h3>
            <p className="text-cream/80 max-w-xl mx-auto mb-6 text-sm sm:text-base">
              Chat directly with our sustainability specialists on WhatsApp for personalized product advice, bulk rates, and doorstep delivery across India.
            </p>
            <a
              href="https://wa.me/919841202464?text=Hi%20GK%20Traders!%20I%20read%20your%20blog%20and%20would%20like%20to%20know%20more%20about%20your%20eco-friendly%20products."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] text-white px-8 py-3.5 rounded-full font-bold hover:bg-[#20bd5a] transition-all shadow-md hover:scale-105"
            >
              <FaWhatsapp size={20} /> Chat & Order on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

