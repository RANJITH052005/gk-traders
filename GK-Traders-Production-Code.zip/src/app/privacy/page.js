import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';

export const metadata = {
  title: 'Privacy Policy | GK Traders',
  description: 'Privacy policy for GK Traders.',
};

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image src="/logo.jpg" alt="GK Watermark" width={500} height={500} className="object-contain mix-blend-multiply" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="bg-white rounded-3xl shadow-sm border border-sand/30 p-8 sm:p-12">
          <div className="flex items-center gap-2 text-forest font-semibold mb-3">
            <FaLeaf className="text-leaf" /> Data Protection
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-darkforest mb-6">
            Privacy Policy
          </h1>
          <p className="text-sm text-gray-500 mb-8">Last updated: October 2026</p>

          <div className="space-y-6 text-gray-700 leading-relaxed text-sm sm:text-base">
            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">1. Information We Collect</h2>
              <p>
                When you make a purchase or register on our site, we collect personal information you give us such as your name, delivery address, email address, and phone number to fulfill and deliver your orders.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">2. How We Use Your Information</h2>
              <ul className="list-disc pl-5 space-y-1">
                <li>To process and fulfill your orders and shipments.</li>
                <li>To send order confirmation and dispatch notifications via SMS / WhatsApp.</li>
                <li>To assist you with customer service and support inquiries.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">3. Payment Security</h2>
              <p>
                GK Traders does not store your credit card, debit card, or UPI credentials. All transactions are securely routed through <strong>Razorpay</strong>, which adheres strictly to PCI-DSS standards.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">4. Third-Party Services</h2>
              <p>
                In general, the third-party providers used by us (such as delivery partners and payment gateways) will only collect, use, and disclose your information to the extent necessary to perform the services they provide to us.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-darkforest mb-2">5. Contact Us</h2>
              <p>
                If you have questions about our privacy practices, please contact us at:
              </p>
              <ul className="list-none pl-0 mt-2 space-y-1 text-sm">
                <li><strong>GK Traders</strong></li>
                <li>Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092</li>
                <li>Email: hellogktraders@gmail.com</li>
                <li>Phone: +91 9841202464</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

