'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';
import { useAuth } from '@/context/AuthContext';

export default function SignupPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const { signUp } = useAuth();
  const router = useRouter();

  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setLoading(true);

    try {
      const { data, error: signUpError } = await signUp(email, password, {
        data: {
          full_name: fullName,
        },
      });

      if (signUpError) {
        if (
          signUpError.status === 522 || 
          signUpError.name === 'AuthRetryableFetchError' || 
          signUpError.message?.toLowerCase().includes('fetch')
        ) {
          setError('Database service is still waking up from pause. Please wait 1–2 minutes for Supabase to finish initializing and try again.');
        } else {
          setError(signUpError.message || 'Failed to sign up. Please try again.');
        }
      } else {
        setSuccess(true);
      }
    } catch (err) {
      if (err?.message?.toLowerCase().includes('fetch')) {
        setError('Database service is still waking up from pause. Please wait 1–2 minutes for Supabase to finish initializing and try again.');
      } else {
        setError(err?.message || 'An unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream py-16 px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={650} 
          height={650} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-sm border border-sand/40 p-8 sm:p-10 relative z-10">
        {/* Brand Logo & Header */}
        <div className="flex flex-col items-center mb-8 text-center">
          <Link
            href="/"
            className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-forest/30 shadow-sm bg-white p-1 mb-4 block hover:border-forest transition-colors"
          >
            <Image
              src="/logo.jpg"
              alt="GK Traders Logo"
              fill
              className="object-contain"
              priority
            />
          </Link>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-leaf mb-2 bg-leaf/10 px-3 py-1 rounded-full">
            <FaLeaf size={11} /> Eco Community
          </div>
          <h1 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest">
            Create an Account
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Join GK Traders and start your eco-friendly journey
          </p>
        </div>

        {/* Success View */}
        {success ? (
          <div className="text-center py-4 space-y-4">
            <div className="w-16 h-16 bg-leaf/20 text-forest rounded-full flex items-center justify-center mx-auto text-3xl font-bold">
              ✓
            </div>
            <h2 className="text-xl font-heading font-bold text-darkforest">
              Check Your Email!
            </h2>
            <p className="text-sm text-gray-600 leading-relaxed">
              We&apos;ve sent a confirmation email to{' '}
              <span className="font-semibold text-darkforest">{email}</span>.
              Please check your inbox and verify your email address to complete registration.
            </p>
            <div className="pt-4">
              <Link
                href="/auth/login"
                className="inline-block w-full py-3.5 px-4 rounded-xl bg-forest hover:bg-darkforest text-cream font-bold text-sm transition-all shadow-md text-center hover:scale-[1.01] transform"
              >
                Go to Sign In
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Error Message */}
            {error && (
              <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-start gap-2">
                <span className="font-semibold">Error:</span>
                <span>{error}</span>
              </div>
            )}

            {/* Signup Form */}
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <label
                  htmlFor="fullName"
                  className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-1.5"
                >
                  Full Name
                </label>
                <input
                  id="fullName"
                  name="fullName"
                  type="text"
                  autoComplete="name"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="email"
                  className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-1.5"
                >
                  Email Address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="password"
                  className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-1.5"
                >
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="confirmPassword"
                  className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-1.5"
                >
                  Confirm Password
                </label>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your password"
                  className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-xl bg-forest hover:bg-darkforest text-cream font-bold text-sm transition-all shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-forest disabled:opacity-60 disabled:cursor-not-allowed mt-2 cursor-pointer hover:scale-[1.01] transform"
              >
                {loading ? 'Creating Account...' : 'Sign Up'}
              </button>
            </form>

            {/* Footer Link to Login */}
            <div className="mt-8 pt-6 border-t border-sand/30 text-center">
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <Link
                  href="/auth/login"
                  className="font-bold text-forest hover:text-darkforest hover:underline transition-colors"
                >
                  Sign in
                </Link>
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
