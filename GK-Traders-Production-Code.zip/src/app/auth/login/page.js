'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { FaLeaf } from 'react-icons/fa';
import { useAuth } from '@/context/AuthContext';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { signInWithEmail } = useAuth();
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data, error: signInError } = await signInWithEmail(email, password);

      if (signInError) {
        if (
          signInError.status === 522 || 
          signInError.name === 'AuthRetryableFetchError' || 
          signInError.message?.toLowerCase().includes('fetch')
        ) {
          setError('Database service is still waking up from pause. Please wait 1–2 minutes for Supabase to finish initializing and try again.');
        } else {
          setError(signInError.message || 'Invalid email or password.');
        }
      } else {
        router.push('/');
      }
    } catch (err) {
      if (err?.message?.toLowerCase().includes('fetch')) {
        setError('Database service is still waking up from pause. Please wait 1–2 minutes for Supabase to finish initializing and try again.');
      } else {
        setError(err?.message || 'An unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream py-16 px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={650} 
          height={650} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-sm border border-sand/40 p-8 sm:p-10 relative z-10">
        {/* Brand Logo & Header */}
        <div className="flex flex-col items-center mb-8 text-center">
          <Link
            href="/"
            className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-forest/30 shadow-sm bg-white p-1 mb-4 block hover:border-forest transition-colors"
          >
            <Image
              src="/logo.jpg"
              alt="GK Traders Logo"
              fill
              className="object-contain"
              priority
            />
          </Link>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-leaf mb-2 bg-leaf/10 px-3 py-1 rounded-full">
            <FaLeaf size={11} /> Conscious Living
          </div>
          <h1 className="text-2xl sm:text-3xl font-heading font-bold text-darkforest">
            Welcome Back
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Sign in to your GK Traders eco account
          </p>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-start gap-2">
            <span className="font-semibold">Error:</span>
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label
              htmlFor="email"
              className="block text-xs font-bold uppercase tracking-wider text-darkforest mb-1.5"
            >
              Email Address
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="password"
                className="block text-xs font-bold uppercase tracking-wider text-darkforest"
              >
                Password
              </label>
            </div>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-3 rounded-xl border border-sand/60 focus:outline-none focus:ring-2 focus:ring-forest bg-cream/20 text-darkforest text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-xl bg-forest hover:bg-darkforest text-cream font-bold text-sm transition-all shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-forest disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer hover:scale-[1.01] transform"
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {/* Footer Link to Signup */}
        <div className="mt-8 pt-6 border-t border-sand/30 text-center">
          <p className="text-sm text-gray-600">
            Don&apos;t have an account?{' '}
            <Link
              href="/auth/signup"
              className="font-bold text-forest hover:text-darkforest hover:underline transition-colors"
            >
              Sign up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
