import Image from 'next/image';
import { FaMapMarkerAlt, FaPhone, FaEnvelope, FaWhatsapp, FaLeaf, FaTruck, FaShieldAlt } from 'react-icons/fa';
import ContactForm from '@/components/ContactForm';

export const metadata = {
  title: 'Contact Us | GK Traders - Eco-Friendly Products Chennai',
  description: 'Get in touch with GK Traders in Virugambakkam, Chennai. Call or WhatsApp +91 9841202464 or email hellogktraders@gmail.com.',
};

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none select-none z-0">
        <Image 
          src="/logo.jpg" 
          alt="GK Traders Watermark" 
          width={700} 
          height={700} 
          className="object-contain mix-blend-multiply" 
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Heading & Description */}
        <div className="text-center mb-12 flex flex-col items-center">
          <div className="inline-flex items-center gap-2 bg-leaf/15 text-forest text-xs font-bold uppercase tracking-widest px-3.5 py-1.5 rounded-full mb-3 border border-forest/10">
            <FaLeaf className="text-leaf" /> We&apos;d Love to Hear From You
          </div>
          <h1 className="text-4xl sm:text-5xl font-heading font-bold text-darkforest mb-4">
            Get in Touch
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
            Have questions about our eco-friendly products, wholesale orders, or shipping? Reach out to our friendly team in Virugambakkam, Chennai.
          </p>
        </div>

        {/* Two-panel layout in bg-white rounded-3xl */}
        <div className="bg-white rounded-3xl shadow-sm border border-sand/40 overflow-hidden flex flex-col lg:flex-row mb-12">
          {/* Left panel (bg-forest text-cream) */}
          <div className="w-full lg:w-5/12 bg-forest text-cream p-8 sm:p-10 flex flex-col justify-between relative overflow-hidden">
            {/* Subtle card watermark */}
            <div className="absolute -bottom-10 -right-10 pointer-events-none select-none opacity-10">
              <Image src="/logo.jpg" alt="" width={250} height={250} className="mix-blend-multiply" />
            </div>

            <div className="relative z-10">
              <span className="text-leaf text-xs font-bold uppercase tracking-widest block mb-2">Direct Support</span>
              <h2 className="text-2xl font-heading font-bold mb-8">Contact Information</h2>
              <div className="space-y-6 text-sm sm:text-base">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0 text-leaf">
                    <FaMapMarkerAlt size={18} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cream mb-1">Our Registered Office</h3>
                    <p className="text-cream/80 text-sm leading-relaxed">
                      Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092, Tamil Nadu, India
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0 text-leaf">
                    <FaPhone size={16} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cream mb-1">Phone Number</h3>
                    <a 
                      href="tel:+919841202464" 
                      className="text-cream/90 text-sm hover:text-white transition-colors block font-medium"
                    >
                      +91 9841202464
                    </a>
                    <span className="text-xs text-cream/60">Mon - Sat: 9:00 AM - 7:00 PM IST</span>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0 text-leaf">
                    <FaEnvelope size={16} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cream mb-1">Email Address</h3>
                    <a 
                      href="mailto:hellogktraders@gmail.com" 
                      className="text-cream/90 text-sm hover:text-white transition-colors block font-medium"
                    >
                      hellogktraders@gmail.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-6 border-t border-cream/20 relative z-10">
              <a 
                href="https://wa.me/919841202464" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white py-3.5 px-6 rounded-2xl font-bold w-full transition-all shadow-md text-sm cursor-pointer hover:scale-[1.02] transform"
              >
                <FaWhatsapp size={20} />
                <span>Chat on WhatsApp (+91 9841202464)</span>
              </a>
            </div>
          </div>

          {/* Right panel: Contact form + Google Maps */}
          <div className="w-full lg:w-7/12 p-8 sm:p-10 flex flex-col justify-between">
            <ContactForm />

            {/* Google Maps iframe */}
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-darkforest mb-2">
                <FaMapMarkerAlt className="text-leaf" /> Chennai Location
              </div>
              <div className="rounded-2xl overflow-hidden h-56 border border-sand/40 shadow-xs">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15547.464619472658!2d80.1834279!3d13.0441951!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a52613524b80b7b%3A0x7d2ecbc36940df!2sVirugambakkam%2C%20Chennai!5e0!3m2!1sen!2sin!4v1716301234567" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  loading="lazy"
                  title="GK Traders Location Map - Virugambakkam Chennai"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          </div>
        </div>

        {/* Eco Trust Badges */}
        <div className="bg-white/80 backdrop-blur-xs rounded-2xl p-6 border border-sand/40 flex flex-wrap items-center justify-around gap-6 text-sm text-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-forest/10 flex items-center justify-center text-forest">
              <FaLeaf className="text-leaf" />
            </div>
            <div>
              <span className="font-bold text-darkforest block text-xs">100% Eco-Friendly</span>
              <span className="text-xs text-gray-500">Plastic-free materials</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-forest/10 flex items-center justify-center text-forest">
              <FaTruck className="text-leaf" />
            </div>
            <div>
              <span className="font-bold text-darkforest block text-xs">Flat ₹59 Delivery</span>
              <span className="text-xs text-gray-500">Everywhere in India</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-forest/10 flex items-center justify-center text-forest">
              <FaShieldAlt className="text-leaf" />
            </div>
            <div>
              <span className="font-bold text-darkforest block text-xs">Direct Support</span>
              <span className="text-xs text-gray-500">+91 9841202464</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
