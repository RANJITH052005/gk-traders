'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);

  // Always use localStorage for cart - simple and reliable
  useEffect(() => {
    loadCartFromLocal();
  }, [user]);

  const loadCartFromLocal = () => {
    try {
      const local = localStorage.getItem('gk_cart');
      if (local) {
        setCartItems(JSON.parse(local));
      } else {
        setCartItems([]);
      }
    } catch (err) {
      setCartItems([]);
    }
    setLoading(false);
  };

  const saveToLocal = (items) => {
    localStorage.setItem('gk_cart', JSON.stringify(items));
  };

  const addToCart = (product, quantity = 1, silent = false) => {
    const newItems = [...cartItems];
    const existing = newItems.find(
      (item) => item.product?.slug === product.slug || item.product?.id === product.id
    );
    if (existing) {
      existing.quantity += quantity;
    } else {
      newItems.push({
        id: Date.now().toString(),
        product: {
          id: product.id,
          slug: product.slug,
          name: product.name,
          price: product.price,
          compare_at_price: product.compare_at_price,
          image_url: product.image_url || product.image,
        },
        quantity,
      });
    }
    setCartItems(newItems);
    saveToLocal(newItems);
    if (!silent) {
      alert('✅ Item added to cart!');
    }
  };

  const updateQuantity = (itemId, quantity) => {
    if (quantity < 1) return;
    const newItems = cartItems.map((item) =>
      item.id === itemId ? { ...item, quantity } : item
    );
    setCartItems(newItems);
    saveToLocal(newItems);
  };

  const removeItem = (itemId) => {
    const newItems = cartItems.filter((item) => item.id !== itemId);
    setCartItems(newItems);
    saveToLocal(newItems);
  };

  const clearCart = () => {
    setCartItems([]);
    saveToLocal([]);
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const cartTotal = cartItems.reduce(
    (acc, item) => acc + ((item.product?.price || 0) * item.quantity),
    0
  );

  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartCount,
        cartTotal,
        loading,
        addToCart,
        updateQuantity,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
