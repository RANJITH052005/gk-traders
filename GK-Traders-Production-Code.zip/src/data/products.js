export const PRODUCTS = [
  {
    id: '1',
    slug: 'eco-friendly-glass-bottle-kids-330ml',
    category: 'Bottles',
    name: 'Eco-Friendly Glass Bottle (330ml) Kids',
    price: 199,
    compare_at_price: 299,
    image: '/images/glass-bottle-kids-pink-eco-view.jpg',
    images: [
      { url: '/images/glass-bottle-kids-pink-eco-view.jpg', label: 'Eco Nature Background' },
      { url: '/images/glass-bottle-kids-pink-white-studio.jpg', label: 'Plain White Studio Background' }
    ],
    description: 'Safe, BPA-free glass bottle designed for little hands. Crystal-clear borosilicate glass with protective silicone sleeve keeps water pure and free from harmful toxins.',
    features: [
      '100% BPA-free borosilicate glass — zero harmful chemicals leach into water',
      'Compact 330ml capacity with cute animal silicone sleeve for drop protection',
      'Leak-proof lid with food-grade silicone seal and convenient carry strap',
      'Dishwasher safe and easy to clean — no odour or taste retention',
      'Available in 3 child-friendly pastel shades: Blossom Pink, Meadow Green, Earth Brown'
    ],
    colors: [
      {
        name: 'Pink',
        hex: '#E4A2A9',
        image: '/images/glass-bottle-kids-pink-eco-view.jpg',
        images: [
          { url: '/images/glass-bottle-kids-pink-eco-view.jpg', label: 'Eco Nature Background' },
          { url: '/images/glass-bottle-kids-pink-white-studio.jpg', label: 'Plain White Studio Background' }
        ]
      },
      {
        name: 'Green',
        hex: '#87C89F',
        image: '/images/glass-bottle-kids-green-eco-view.jpg',
        images: [
          { url: '/images/glass-bottle-kids-green-eco-view.jpg', label: 'Eco Nature Background' },
          { url: '/images/glass-bottle-kids-green-white-studio.jpg', label: 'Plain White Studio Background' }
        ]
      },
      {
        name: 'Brown',
        hex: '#D7AE86',
        image: '/images/glass-bottle-kids-brown-eco-view.jpg',
        images: [
          { url: '/images/glass-bottle-kids-brown-eco-view.jpg', label: 'Eco Nature Background' },
          { url: '/images/glass-bottle-kids-brown-white-studio.jpg', label: 'Plain White Studio Background' }
        ]
      }
    ],
    relatedBlogSlug: 'say-goodbye-to-plastic-bottles-for-kids',
    relatedBlogTitle: 'Safe Hydration: Why Glass Beats Plastic Bottles for Children'
  },
  {
    id: '2',
    slug: 'eco-friendly-bamboo-bottle-750ml',
    category: 'Bottles',
    name: 'Eco-Friendly Bamboo Bottle (750ml)',
    price: 320,
    compare_at_price: 499,
    image: '/images/bamboo-bottle-eco-view.jpg',
    images: [
      { url: '/images/bamboo-bottle-eco-view.jpg', label: 'Eco Nature Background' },
      { url: '/images/bamboo-bottle-white-studio.jpg', label: 'Plain White Studio Background' }
    ],
    description: 'Premium bamboo-clad double-wall bottle that keeps drinks hot for 12 hours and cold for 24 hours. Naturally antibacterial, food-safe, and leak-proof.',
    features: [
      'Double-wall vacuum insulation — keeps liquids hot for 12 hrs, cold for 24 hrs',
      'Real natural bamboo casing with 304 food-grade stainless steel interior',
      'Wide mouth design for effortless filling, ice cubes, and thorough cleaning',
      'Airtight leak-proof cap with integrated stainless steel carry loop',
      'Naturally antibacterial organic bamboo exterior that feels warm and earthy'
    ]
  },
  {
    id: '3',
    slug: 'eco-friendly-bamboo-toothbrush',
    category: 'Oral Care',
    name: 'Eco-Friendly Bamboo Toothbrush',
    price: 99,
    compare_at_price: 149,
    image: '/images/bamboo-toothbrush-eco-view.jpg',
    images: [
      { url: '/images/bamboo-toothbrush-eco-view.jpg', label: 'Eco Nature Background' },
      { url: '/images/bamboo-toothbrush-white-studio.jpg', label: 'Plain White Studio Background' }
    ],
    description: '100% biodegradable Moso bamboo handle with soft charcoal-infused bristles. Naturally antimicrobial — fights bacteria while being gentle on gums.',
    features: [
      'Organic Moso bamboo handle — naturally decomposes in soil within months',
      'Charcoal-infused BPA-free soft bristles for deep plaque removal',
      'Naturally antimicrobial handle that resists bathroom mould & germs',
      'Ergonomic smooth splinter-free curve for comfortable daily brushing',
      '100% plastic-free compostable kraft packaging'
    ],
    relatedBlogSlug: 'why-switch-to-bamboo-toothbrushes',
    relatedBlogTitle: 'Why Switching to a Bamboo Toothbrush Matters More Than You Think'
  },
  {
    id: '4',
    slug: 'eco-friendly-bamboo-tongue-cleaner',
    category: 'Oral Care',
    name: 'Eco-Friendly Bamboo Tongue Cleaner',
    price: 79,
    compare_at_price: 129,
    image: '/images/bamboo-tongue-cleaner-eco-view.jpg',
    images: [
      { url: '/images/bamboo-tongue-cleaner-eco-view.jpg', label: 'Eco Nature Background' },
      { url: '/images/bamboo-tongue-cleaner-white-studio.jpg', label: 'Plain White Studio Background' }
    ],
    description: 'Handcrafted ergonomic U-shape bamboo scraper for fresh morning breath and Ayurvedic oral care. Removes 90% more oral bacteria than brushing alone.',
    features: [
      'Ergonomic flexible U-shape design tailored for comfortable tongue scraping',
      'Smooth hand-polished rounded edges — zero cuts, scrapes, or tongue irritation',
      'Ayurvedic toxin (Ama) removal for fresher breath and restored taste buds',
      'Naturally antibacterial bamboo that stays clean and hygienic',
      'Comes in a reusable breathable cotton carry pouch'
    ],
    relatedBlogSlug: 'ancient-science-of-bamboo-tongue-cleaners',
    relatedBlogTitle: 'The Ancient Ayurvedic Science of Bamboo Tongue Scraping'
  },
  {
    id: '5',
    slug: 'eco-friendly-coconut-vessel-scrub',
    category: 'Kitchen',
    name: 'Eco-Friendly Coconut Vessel Scrub',
    price: 18,
    boxPrice: 90,
    boxCount: 5,
    pricingNote: '₹18 / pc • Box of 5: ₹90',
    compare_at_price: 30,
    image: '/images/coconut-scrub-single-eco-v2.jpg',
    images: [
      { url: '/images/coconut-scrub-single-eco-v2.jpg', label: 'Eco Nature Background' },
      { url: '/images/coconut-scrub-single-white-v2.jpg', label: 'Plain White Studio Background' }
    ],
    packImages: {
      single: [
        { url: '/images/coconut-scrub-single-eco-v2.jpg', label: 'Eco Nature Background' },
        { url: '/images/coconut-scrub-single-white-v2.jpg', label: 'Plain White Studio Background' }
      ],
      box: [
        { url: '/images/coconut-scrub-box-eco-v2.jpg', label: 'Eco Nature Background' },
        { url: '/images/coconut-scrub-box-white-v2.jpg', label: 'Plain White Studio Background' }
      ]
    },
    description: 'Made from 100% natural South Indian coconut coir fibre with reinforced stitching. Heavy-duty on tough grease, yet 100% scratch-safe on non-stick utensils.',
    features: [
      '100% natural coconut coir — fully compostable and zero microplastic waste',
      'Available as Single Piece (₹18) or Value Box of 5 (₹90)',
      'Reinforced perimeter zigzag stitching for extended longevity',
      'Safe for non-stick cookware, glassware, cast iron, and ceramics',
      'Naturally antibacterial and odour-resistant — dries quickly without smelling'
    ],
    relatedBlogSlug: 'coconut-coir-the-natural-kitchen-powerhouse',
    relatedBlogTitle: 'Coconut Coir: How Tradition Solved Kitchen Grease'
  },
  {
    id: '6',
    slug: 'eco-friendly-bamboo-comb',
    category: 'Personal Care',
    name: 'Eco-Friendly Bamboo Comb',
    price: 49,
    compare_at_price: 99,
    image: '/images/bamboo-comb-eco-view.jpg',
    images: [
      { url: '/images/bamboo-comb-eco-view.jpg', label: 'Eco Nature Background' },
      { url: '/images/bamboo-comb-white-studio.jpg', label: 'Plain White Studio Background' }
    ],
    description: 'Handcrafted natural neem and bamboo hair comb that eliminates static frizz, prevents hair breakage, and stimulates healthy scalp circulation.',
    features: [
      'Handcrafted natural wood with anti-static and anti-dandruff benefits',
      'Smooth polished rounded teeth that gently massage the scalp',
      'Prevents split ends and hair snagging during daily detangling',
      'Distributes natural scalp oils evenly from roots to tips',
      'Compact, durable, and 100% biodegradable zero-plastic design'
    ]
  }
];

export const STATIC_PRODUCTS = PRODUCTS;
