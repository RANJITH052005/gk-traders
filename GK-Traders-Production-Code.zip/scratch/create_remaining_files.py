import os

base_dir = r"c:\Users\R vishnupriya\Downloads\GK Traders\frontend"

files = {
    "src/app/cart/page.js": """'use client';
import Link from 'next/link';
import Image from 'next/image';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { FaTrash, FaMinus, FaPlus, FaShoppingCart } from 'react-icons/fa';

export default function CartPage() {
  const { cartItems, updateQuantity, removeItem, cartTotal } = useCart();
  const { user } = useAuth();
  const router = useRouter();

  const handleCheckout = () => {
    if (!user) {
      router.push('/auth/login?redirect=/checkout');
    } else {
      router.push('/checkout');
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-cream py-20 px-4 flex flex-col items-center justify-center">
        <FaShoppingCart className="text-sand/30 text-8xl mb-6" />
        <h2 className="text-3xl font-heading font-bold text-darkforest mb-4">Your Cart is Empty</h2>
        <p className="text-gray-600 mb-8 text-center max-w-md">Looks like you haven't added any eco-friendly products to your cart yet.</p>
        <Link href="/products" className="bg-forest text-cream px-8 py-3 rounded-full font-bold hover:bg-darkforest transition-colors shadow-md">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-darkforest mb-8">Shopping Cart ({cartItems.length} items)</h1>
        
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="w-full lg:w-2/3">
            <div className="bg-white rounded-2xl shadow-sm border border-sand/30 overflow-hidden">
              {/* Header */}
              <div className="hidden sm:grid grid-cols-12 gap-4 p-4 border-b border-gray-100 bg-gray-50 text-sm font-semibold text-gray-500 uppercase tracking-wider">
                <div className="col-span-6">Product</div>
                <div className="col-span-2 text-center">Price</div>
                <div className="col-span-2 text-center">Quantity</div>
                <div className="col-span-2 text-right">Subtotal</div>
              </div>
              
              {/* Items */}
              <div className="divide-y divide-gray-100">
                {cartItems.map((item) => (
                  <div key={item.id} className="p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                    <div className="col-span-1 sm:col-span-6 flex items-center gap-4">
                      <div className="w-20 h-20 relative rounded-lg overflow-hidden bg-gray-50 flex-shrink-0 border border-gray-100">
                        {item.product.image ? (
                          <Image src={item.product.image} alt={item.product.name} fill className="object-cover" />
                        ) : (
                          <div className="w-full h-full bg-sand/20"></div>
                        )}
                      </div>
                      <div>
                        <Link href={`/products/${item.product.slug || item.product.id}`} className="font-heading font-semibold text-forest hover:text-leaf transition-colors line-clamp-2">
                          {item.product.name}
                        </Link>
                        <button 
                          onClick={() => removeItem(item.id)}
                          className="text-red-500 text-sm flex items-center gap-1 mt-2 hover:text-red-700 transition-colors"
                        >
                          <FaTrash size={12} /> Remove
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 sm:col-span-2 text-center hidden sm:block font-medium text-gray-600">
                      ₹{item.product.price}
                    </div>
                    
                    <div className="col-span-1 sm:col-span-2 flex justify-center">
                      <div className="flex items-center border border-gray-200 rounded-lg bg-white">
                        <button 
                          onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="p-2 hover:bg-gray-50 text-gray-600 transition-colors"
                        >
                          <FaMinus size={10} />
                        </button>
                        <span className="w-8 text-center font-medium text-sm">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-2 hover:bg-gray-50 text-gray-600 transition-colors"
                        >
                          <FaPlus size={10} />
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 sm:col-span-2 text-right font-bold text-darkforest flex justify-between sm:block">
                      <span className="sm:hidden text-gray-500 font-normal">Subtotal:</span>
                      ₹{item.product.price * item.quantity}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/3">
            <div className="bg-white rounded-2xl shadow-sm border border-sand/30 p-6 sticky top-24">
              <h2 className="text-xl font-heading font-bold text-darkforest mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span className="font-medium">₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Shipping</span>
                  <span className="text-leaf font-medium">Free</span>
                </div>
                <div className="border-t border-gray-100 pt-4 flex justify-between items-center">
                  <span className="text-lg font-bold text-darkforest">Total</span>
                  <span className="text-2xl font-bold text-forest">₹{cartTotal}</span>
                </div>
              </div>
              
              <button 
                onClick={handleCheckout}
                className="w-full bg-forest text-cream py-4 rounded-xl font-bold text-lg hover:bg-darkforest transition-colors shadow-md"
              >
                Proceed to Checkout
              </button>
              
              <div className="mt-4 text-center">
                <Link href="/products" className="text-sm text-leaf hover:text-forest transition-colors font-medium">
                  Continue Shopping
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/checkout/page.js": """'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';
import { loadRazorpayScript } from '@/lib/razorpay';
import { FaCheckCircle, FaSpinner } from 'react-icons/fa';

export default function CheckoutPage() {
  const { user, loading: authLoading } = useAuth();
  const { cartItems, cartTotal, clearCart } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [address, setAddress] = useState({
    name: '', phone: '', addressLine1: '', addressLine2: '', city: '', state: '', pincode: '',
  });

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/login?redirect=/checkout');
    }
  }, [user, authLoading, router]);

  const handleChange = (e) => setAddress({ ...address, [e.target.name]: e.target.value });

  const handlePayment = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await loadRazorpayScript();
      if (!res) {
        setError("Razorpay SDK failed to load.");
        setLoading(false);
        return;
      }

      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "rzp_test_123456",
        amount: cartTotal * 100,
        currency: "INR",
        name: "GK Traders",
        description: "Eco-Friendly Products",
        handler: function (response) {
          clearCart();
          router.push('/orders/12345?success=true');
        },
        prefill: { name: address.name, email: user?.email || '', contact: address.phone },
        theme: { color: "#2d6a4f" },
      };

      const paymentObject = new window.Razorpay(options);
      paymentObject.open();
    } catch (err) {
      setError("Payment initialization failed.");
    } finally {
      setLoading(false);
    }
  };

  if (authLoading || !user) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-cream py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-darkforest mb-8 text-center">Secure Checkout</h1>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Shipping Form */}
          <div className="w-full lg:w-2/3">
            <div className="bg-white rounded-2xl shadow-sm border border-sand/30 p-6 sm:p-8">
              <h2 className="text-xl font-heading font-semibold text-forest mb-6 flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-leaf text-darkforest flex items-center justify-center text-sm">1</span> Shipping Address
              </h2>
              <form onSubmit={handlePayment} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input required type="text" name="name" value={address.name} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input required type="tel" name="phone" value={address.phone} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 1</label>
                  <input required type="text" name="addressLine1" value={address.addressLine1} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                    <input required type="text" name="city" value={address.city} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                    <input required type="text" name="state" value={address.state} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Pincode</label>
                    <input required type="text" name="pincode" value={address.pincode} onChange={handleChange} className="w-full border border-gray-300 rounded-lg p-2.5 outline-none" />
                  </div>
                </div>
                {error && <p className="text-red-500 text-sm">{error}</p>}
                <div className="pt-4 border-t border-gray-100">
                  <button type="submit" disabled={loading || cartItems.length === 0} className="w-full bg-forest text-cream py-4 rounded-xl font-bold text-lg hover:bg-darkforest disabled:opacity-70 flex items-center justify-center gap-2">
                    {loading ? <FaSpinner className="animate-spin" /> : <FaCheckCircle />} Pay ₹{cartTotal} Securely
                  </button>
                </div>
              </form>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="w-full lg:w-1/3">
            <div className="bg-white rounded-2xl shadow-sm border border-sand/30 p-6 sticky top-24">
              <h2 className="text-xl font-heading font-semibold text-forest mb-4 flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-leaf text-darkforest flex items-center justify-center text-sm">2</span> Order Summary
              </h2>
              <div className="max-h-60 overflow-y-auto mb-4 pr-2 space-y-3">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-800 line-clamp-1">{item.quantity}x {item.product.name}</span>
                    <span className="font-medium">₹{item.product.price * item.quantity}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-100 pt-4 space-y-3 text-sm">
                <div className="flex justify-between text-gray-600"><span>Subtotal</span><span className="font-medium">₹{cartTotal}</span></div>
                <div className="flex justify-between text-gray-600"><span>Shipping</span><span className="text-leaf font-medium">Free</span></div>
                <div className="border-t border-gray-100 pt-3 flex justify-between items-center">
                  <span className="text-lg font-bold text-darkforest">Total</span>
                  <span className="text-xl font-bold text-forest">₹{cartTotal}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/about/page.js": """import { FaLeaf, FaGlobeAmericas, FaRecycle } from 'react-icons/fa';
export default function AboutPage() {
  return (
    <div className="min-h-screen bg-cream">
      <div className="bg-forest py-20 text-center text-cream">
        <h1 className="text-4xl font-heading font-bold mb-4">About GK Traders</h1>
        <p className="text-lg max-w-2xl mx-auto opacity-90 font-light">Your partner for a sustainable lifestyle.</p>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-heading font-bold text-darkforest mb-4">Why Go Eco-Friendly?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl border-t-4 border-leaf shadow-sm">
              <h3 className="text-xl font-bold text-forest mb-3">Reduce Plastic</h3>
              <p className="text-gray-600">Prevent microplastics from harming marine life.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl border-t-4 border-sand shadow-sm">
              <h3 className="text-xl font-bold text-forest mb-3">Healthier</h3>
              <p className="text-gray-600">Our products are free from BPA and harmful toxins.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl border-t-4 border-darkforest shadow-sm">
              <h3 className="text-xl font-bold text-forest mb-3">Sustainable</h3>
              <p className="text-gray-600">Bamboo grows fast, making it renewable.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/contact/page.js": """import { FaMapMarkerAlt, FaPhone, FaEnvelope, FaWhatsapp } from 'react-icons/fa';
export default function ContactPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4">
      <div className="max-w-7xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-heading font-bold text-darkforest">Get in Touch</h1>
      </div>
      <div className="flex flex-col lg:flex-row gap-12 bg-white rounded-3xl shadow-sm overflow-hidden max-w-5xl mx-auto">
        <div className="w-full lg:w-1/3 bg-forest text-cream p-8 flex flex-col justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-8">Contact Info</h2>
            <div className="space-y-6">
              <p>Old No. 48, New No. 19, 3rd Street, Krishna Nagar, Virugambakkam, Chennai – 600092</p>
              <p>+91 9841202464</p>
              <p>hellogktraders@gmail.com</p>
            </div>
          </div>
        </div>
        <div className="w-full lg:w-2/3 p-8">
          <h2 className="text-2xl font-bold text-darkforest mb-6">Send us a Message</h2>
          <form className="space-y-6">
            <input type="text" className="w-full border p-3 rounded" placeholder="Your Name" />
            <input type="email" className="w-full border p-3 rounded" placeholder="Your Email" />
            <textarea className="w-full border p-3 rounded" rows="4" placeholder="Message"></textarea>
            <button className="bg-forest text-cream py-3 px-8 rounded">Send</button>
          </form>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/auth/login/page.js": """'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import { FaLeaf } from 'react-icons/fa';

export default function LoginPage() {
  const { signInWithEmail } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { error } = await signInWithEmail(email, password);
      if (error) throw error;
      router.push('/');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-cream flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <FaLeaf className="mx-auto text-leaf text-4xl mb-4" />
        <h2 className="text-center text-3xl font-heading font-bold text-darkforest">Welcome Back</h2>
      </div>
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-sand/30">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label className="block text-sm font-medium text-gray-700">Email address</label>
              <input type="email" required className="w-full border p-2 rounded" onChange={e => setEmail(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <input type="password" required className="w-full border p-2 rounded" onChange={e => setPassword(e.target.value)} />
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button type="submit" className="w-full bg-forest text-cream py-2 rounded hover:bg-darkforest">Sign In</button>
          </form>
          <div className="mt-6"><GoogleSignInButton /></div>
          <p className="mt-6 text-center text-sm">
            Don't have an account? <Link href="/auth/signup" className="text-leaf">Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/auth/signup/page.js": """'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import { FaLeaf } from 'react-icons/fa';

export default function SignupPage() {
  const { signUp } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { error } = await signUp(email, password);
      if (error) throw error;
      alert("Check your email to verify!");
      router.push('/auth/login');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-cream flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <FaLeaf className="mx-auto text-leaf text-4xl mb-4" />
        <h2 className="text-center text-3xl font-heading font-bold text-darkforest">Join the Green Revolution</h2>
      </div>
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-sand/30">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label className="block text-sm font-medium text-gray-700">Email address</label>
              <input type="email" required className="w-full border p-2 rounded" onChange={e => setEmail(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <input type="password" required className="w-full border p-2 rounded" onChange={e => setPassword(e.target.value)} />
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button type="submit" className="w-full bg-forest text-cream py-2 rounded hover:bg-darkforest">Create Account</button>
          </form>
          <div className="mt-6"><GoogleSignInButton /></div>
          <p className="mt-6 text-center text-sm">
            Already have an account? <Link href="/auth/login" className="text-leaf">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/auth/callback/route.js": """import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function GET(request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const next = searchParams.get('next') ?? '/'

  if (code) {
    const cookieStore = cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
      {
        cookies: {
          get(name) { return cookieStore.get(name)?.value },
          set(name, value, options) { cookieStore.set({ name, value, ...options }) },
          remove(name, options) { cookieStore.set({ name, value: '', ...options }) },
        },
      }
    )
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      return NextResponse.redirect(`${origin}${next}`)
    }
  }
  return NextResponse.redirect(`${origin}/auth/login?error=auth`)
}
""",
    "src/app/orders/page.js": """'use client';
import Link from 'next/link';

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-cream py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-darkforest mb-8">My Orders</h1>
        <div className="bg-white p-8 text-center rounded shadow">
          <p className="text-gray-600 mb-4">No orders yet. Start shopping!</p>
          <Link href="/products" className="bg-forest text-cream px-6 py-2 rounded">Products</Link>
        </div>
      </div>
    </div>
  );
}
""",
    "src/app/orders/[id]/page.js": """'use client';
import { useSearchParams } from 'next/navigation';

export default function OrderDetail({ params }) {
  const searchParams = useSearchParams();
  const isSuccess = searchParams.get('success');

  return (
    <div className="min-h-screen bg-cream py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {isSuccess && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            Payment successful! Your order has been placed.
          </div>
        )}
        <h1 className="text-3xl font-heading font-bold text-darkforest mb-8">Order #{params.id}</h1>
        <div className="bg-white p-6 rounded shadow">
          <p>Status: <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">Confirmed</span></p>
          <p className="mt-4">Thanks for shopping with GK Traders!</p>
          <button className="mt-4 bg-leaf px-4 py-2 rounded text-darkforest font-bold">Track on WhatsApp</button>
        </div>
      </div>
    </div>
  );
}
"""
}

for filepath, content in files.items():
    full_path = os.path.join(base_dir, filepath)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(content)
        
print("Successfully created all remaining files.")
